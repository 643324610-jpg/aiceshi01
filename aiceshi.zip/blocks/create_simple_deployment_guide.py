# 创建简单干净的部署指南HTML文件
guide_content = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 AI网站平台 - 如何部署打开</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
            line-height: 1.7;
            color: #2c3e50;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }
        .content {
            padding: 40px;
        }
        .step {
            margin-bottom: 30px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 12px;
            border-left: 5px solid #667eea;
        }
        .step h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.4rem;
        }
        .step-number {
            display: inline-block;
            width: 30px;
            height: 30px;
            background: #667eea;
            color: white;
            text-align: center;
            line-height: 30px;
            border-radius: 50%;
            margin-right: 10px;
            font-weight: bold;
        }
        .platform-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }
        .platform-card {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        .platform-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            color: white;
            margin-left: 8px;
        }
        .badge-free {
            background: #27ae60;
        }
        .badge-paid {
            background: #f39c12;
        }
        .command {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            font-family: 'Consolas', monospace;
            overflow-x: auto;
        }
        ul {
            padding-left: 20px;
            margin: 10px 0;
        }
        li {
            margin: 8px 0;
        }
        .check-list {
            list-style: none;
            padding-left: 0;
        }
        .check-list li {
            padding-left: 28px;
            position: relative;
        }
        .check-list li:before {
            content: "✓";
            color: #27ae60;
            position: absolute;
            left: 0;
            font-weight: bold;
        }
        .summary-box {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            margin-top: 30px;
        }
        .summary-box h2 {
            color: white;
            margin-bottom: 15px;
        }
        .footer {
            text-align: center;
            padding: 25px;
            color: #6c757d;
            border-top: 1px solid #e9ecef;
        }
        .problem {
            background: #fff5f5;
            border-left: 4px solid #e74c3c;
            padding: 15px;
            border-radius: 0 8px 8px 0;
            margin: 10px 0;
        }
        .problem-title {
            font-weight: bold;
            color: #c0392b;
        }
        a {
            color: #3498db;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .content {
                padding: 20px;
            }
            .platform-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 AI网站平台 - 完整部署指南</h1>
            <p>一步一步教你部署上线，Vercel一键打开访问</p>
        </div>
        
        <div class="content">
            <div class="summary-box">
                <h2>🎯 5分钟快速总结</h2>
                <ol style="text-align: left; font-size: 1.1rem; line-height: 2;">
                    <li>注册 GitHub、Supabase、Vercel、OpenAI、微信/支付宝账号</li>
                    <li>本地配置项目代码，填入环境变量测试</li>
                    <li>推送到 GitHub</li>
                    <li>Vercel 导入项目，点 Deploy</li>
                    <li><strong>等待 2-5 分钟，直接访问 Vercel 给你的域名就能打开！</strong></li>
                </ol>
            </div>
            
            <div class="step">
                <h3><span class="step-number">0</span>前置准备 - 注册账号</h3>
                <p>你需要在这些平台注册账号，大部分都有免费层级可以起步：</p>
                
                <div class="platform-grid">
                    <div class="platform-card">
                        <div class="platform-name">GitHub <span class="badge badge-free">免费</span></div>
                        <div><small>作用：代码托管</small></div>
                        <div><small><a href="https://github.com/" target="_blank">https://github.com/</a></small></div>
                    </div>
                    <div class="platform-card">
                        <div class="platform-name">Supabase <span class="badge badge-free">免费</span></div>
                        <div><small>作用：数据库 + 用户登录</small></div>
                        <div><small><a href="https://supabase.com/" target="_blank">https://supabase.com/</a></small></div>
                    </div>
                    <div class="platform-card">
                        <div class="platform-name">Vercel <span class="badge badge-free">免费</span></div>
                        <div><small>作用：一键部署网站</small></div>
                        <div><small><a href="https://vercel.com/" target="_blank">https://vercel.com/</a></small></div>
                    </div>
                    <div class="platform-card">
                        <div class="platform-name">OpenAI <span class="badge badge-paid">付费</span></div>
                        <div><small>作用：AI聊天 + 画图 API</small></div>
                        <div><small><a href="https://platform.openai.com/" target="_blank">platform.openai.com</a></small></div>
                    </div>
                    <div class="platform-card">
                        <div class="platform-name">微信支付 <span class="badge badge-paid">商户</span></div>
                        <div><small>作用：微信支付接入</small></div>
                        <div><small><a href="https://pay.weixin.qq.com/" target="_blank">pay.weixin.qq.com</a></small></div>
                    </div>
                    <div class="platform-card">
                        <div class="platform-name">支付宝 <span class="badge badge-paid">商户</span></div>
                        <div><small>作用：支付宝接入</small></div>
                        <div><small><a href="https://open.alipay.com/" target="_blank">open.alipay.com</a></small></div>
                    </div>
                </div>
                
                <h4 style="margin-top: 20px;">需要准备的工具：</h4>
                <ul class="check-list">
                    <li>Git (代码版本控制)</li>
                    <li>Node.js 18+ (本地开发环境)</li>
                    <li>VS Code 或其他编辑器</li>
                    <li>命令行终端</li>
                </ul>
            </div>
            
            <div class="step">
                <h3><span class="step-number">1</span>本地开发环境搭建</h3>
                <ol>
                    <li>
                        <strong>克隆/创建项目，安装依赖</strong>
                        <div class="command">
git clone &lt;你的项目地址&gt;<br>
cd 项目目录<br>
npm install
                        </div>
                    </li>
                    <li>
                        <strong>配置环境变量</strong>
                        <div class="command">
cp .env.example .env.local
                        </div>
                        <p>打开 <code>.env.local</code>，填入这些信息：</p>
                        <ul>
                            <li><code>NEXT_PUBLIC_SUPABASE_URL</code> - 从 Supabase 获取</li>
                            <li><code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> - 从 Supabase 获取</li>
                            <li><code>SUPABASE_SERVICE_ROLE_KEY</code> - 从 Supabase 获取</li>
                            <li><code>OPENAI_API_KEY</code> - 从 OpenAI 获取</li>
                            <li><code>WECHAT_APP_ID</code> - 从微信支付获取</li>
                            <li><code>WECHAT_MCH_ID</code> - 微信支付商户号</li>
                            <li><code>ALIPAY_APP_ID</code> - 从支付宝获取</li>
                            <li><code>NEXTAUTH_SECRET</code> - 自己生成一个随机字符串</li>
                            <li><code>NEXTAUTH_URL=http://localhost:3000</code></li>
                        </ul>
                    </li>
                    <li>
                        <strong>启动本地开发服务器</strong>
                        <div class="command">
npm run dev
                        </div>
                        <p>启动成功后，<strong>浏览器打开 <a href="http://localhost:3000" target="_blank">http://localhost:3000</a> 就能看到网站了！</strong></p>
                    </li>
                    <li>
                        <strong>本地测试</strong>
                        <ul class="check-list">
                            <li>注册登录功能正常</li>
                            <li>AI聊天正常响应</li>
                            <li>图像生成功能正常</li>
                            <li>支付流程测试通过</li>
                        </ul>
                    </li>
                </ol>
            </div>
            
            <div class="step">
                <h3><span class="step-number">2</span>Supabase 配置</h3>
                <ol class="check-list">
                    <li>登录 Supabase 官网，点击 <strong>New project</strong></li>
                    <li>输入项目名，选择区域，创建项目</li>
                    <li>等待 1-2 分钟创建完成</li>
                    <li>进入项目 → Settings → API</li>
                    <li>复制 Project URL、anon key、service role key</li>
                    <li>粘贴到你的 <code>.env.local</code> 对应位置</li>
                    <li>在 SQL Editor 执行建表SQL创建数据库表</li>
                    <li>配置认证，设置回调地址</li>
                </ol>
            </div>
            
            <div class="step">
                <h3><span class="step-number">3</span>推送到 GitHub</h3>
                <div class="command">
# 在 GitHub 创建新仓库后，执行：<br>
git init<br>
git remote add origin &lt;你的GitHub仓库地址&gt;<br>
git add .<br>
git commit -m "Initial commit"<br>
git push -u origin main
                </div>
                <p><strong>⚠️ 重要：</strong>确保 <code>.env.local</code> 已经在 <code>.gitignore</code> 中，<strong>绝对不要</strong>把 API 密钥提交到代码仓库！</p>
            </div>
            
            <div class="step">
                <h3><span class="step-number">4</span>Vercel 一键部署</h3>
                <ol>
                    <li>登录 <a href="https://vercel.com/" target="_blank">Vercel 官网</a></li>
                    <li>点击 <strong>New Project</strong></li>
                    <li>选择你刚才推送到 GitHub 的仓库</li>
                    <li>Vercel 会自动识别这是 Next.js 项目</li>
                    <li>在 <strong>Environment Variables</strong> 填入所有环境变量（和本地 <code>.env.local</code> 一样）</li>
                    <li>点击 <strong>Deploy</strong></li>
                    <li>等待 2-5 分钟部署完成</li>
                    <li><strong>完成！Vercel 会给你一个域名，直接访问就能打开网站！🎉</strong></li>
                </ol>
                
                <h4 style="margin-top: 15px;">Vercel 自动帮你做这些：</h4>
                <ul class="check-list">
                    <li>✅ 自动安装依赖</li>
                    <li>✅ 自动构建项目</li>
                    <li>✅ 自动配置 SSL 证书（HTTPS）</li>
                    <li>✅ 自动部署到全球 CDN</li>
                    <li>✅ 自动分配域名</li>
                    <li>✅ 之后每次推送到 GitHub，自动重新部署</li>
                </ul>
            </div>
            
            <div class="step">
                <h3><span class="step-number">5</span>🌐 如何打开访问网站</h3>
                <ul class="check-list">
                    <li><strong>本地开发访问：</strong><br>浏览器直接打开 → <code>http://localhost:3000</code></li>
                    <li><strong>线上预览访问：</strong><br>Vercel 自动给你一个域名，格式像这样 → <code>https://your-project-name.vercel.app</code><br>直接在浏览器打开这个地址就可以访问了！</li>
                    <li><strong>自定义域名访问：</strong><br>如果你有自己的域名，在 Vercel 配置好 DNS 后，直接访问你的域名就行，比如 → <code>https://ai.yourdomain.com</code></li>
                </ul>
                <p style="margin-top: 15px; background: #fff3cd; padding: 10px; border-radius: 5px;">
                    <strong>💡 注意：</strong>第一次打开可能需要几秒钟，这是 Vercel Serverless 冷启动，正常现象，之后访问就快了。
                </p>
            </div>
            
            <div class="step">
                <h3><span class="step-number">6</span>🔧 常见问题排查</h3>
                
                <div class="problem">
                    <div class="problem-title">网站打不开</div>
                    <ul>
                        <li>检查 Vercel 部署是否成功，查看部署日志</li>
                        <li>检查环境变量是否都填写正确</li>
                        <li>检查构建是否出错，看错误信息</li>
                    </ul>
                </div>
                
                <div class="problem">
                    <div class="problem-title">Supabase 连接失败</div>
                    <ul>
                        <li>检查 URL 和 API 密钥是否正确</li>
                        <li>检查项目是否在 Supabase 中正常运行</li>
                        <li>检查网络是否能访问 Supabase</li>
                    </ul>
                </div>
                
                <div class="problem">
                    <div class="problem-title">AI API 调用失败</div>
                    <ul>
                        <li>检查 API 密钥是否正确</li>
                        <li>检查账户余额是否充足</li>
                        <li>检查 API 调用配额是否用完</li>
                    </ul>
                </div>
            </div>
            
            <div class="step">
                <h3><span class="step-number">7</span>🔄 日常更新</h3>
                <p>修改代码后，只需要这几步：</p>
                <div class="command">
git add .<br>
git commit -m "Update: 功能说明"<br>
git push origin main
                </div>
                <p>推送完成后，<strong>Vercel 自动检测到变化，自动重新部署，几分钟就更新上线了！</strong></p>
            </div>
            
            <div class="summary-box">
                <h2>✅ 最终一句话总结</h2>
                <div style="font-size: 1.3rem; line-height: 2;">
                    <strong>注册账号 → 本地配置 → 推 GitHub → Vercel 一键部署 → 直接访问域名打开！</strong>
                    <br>
                    整个过程只需要 <strong>5-10 分钟</strong>（不包含构建等待时间），真的就是一键上线！🚀
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>Generated by <a href="https://www.aipyaipy.com" target="_blank">AiPy</a> | 本地数据处理，不上传任何信息</p>
            <p style="margin-top: 10px;">AI网站平台部署指南 © 2026 | Vercel 一键部署真香！</p>
        </div>
    </div>
</body>
</html>
"""
# 保存HTML文件
with open("how-to-deploy-and-open.html", "w", encoding="utf-8") as f:
    f.write(guide_content)
print("✅ 部署指南生成成功！")
print("📄 文件: how-to-deploy-and-open.html")
print("🌐 直接用浏览器打开这个文件就能查看详细步骤！")
# 同时保存JSON
import json
simple_guide = {
    "summary": "注册账号 → 本地配置 → 推GitHub → Vercel一键部署 → 直接访问域名打开",
    "total_steps": 7,
    "estimated_time": "5-10分钟配置 + 2-5分钟部署",
    "output_file": "how-to-deploy-and-open.html",
    "quick_start": [
        "1. 注册所有需要的平台账号",
        "2. 本地配置项目和环境变量",
        "3. 推送到GitHub",
        "4. Vercel导入项目，填入环境变量，点击Deploy",
        "5. 等待2-5分钟，直接访问Vercel给你的域名就能打开网站！"
    ]
}
with open("deployment_summary.json", "w", encoding="utf-8") as f:
    json.dump(simple_guide, f, ensure_ascii=False, indent=2)
utils.set_state(success=True, 
               files=["how-to-deploy-and-open.html", "deployment_summary.json"],
               message="简洁明了的部署指南已生成完成")