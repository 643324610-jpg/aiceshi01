import os
import shutil
target_dir = r"D:\软件\AI智能体\GitHub电脑版"
# 修复批处理脚本的输出问题
fixed_script = """@echo off
chcp 65001 >nul
echo ========================================
echo    GitHub Desktop 终极中文修复方案
echo ========================================
echo.
echo 此脚本将强制设置GitHub Desktop为中文界面
echo 适用于找不到Preferences或Language选项的情况
echo.
echo 按任意键开始修复...
pause >nul
echo.
echo [步骤1] 检查GitHub Desktop是否运行
tasklist /FI "IMAGENAME eq GitHubDesktop.exe" 2>nul | find /I /N "GitHubDesktop.exe" >nul
if errorlevel 1 (
    echo [OK] GitHub Desktop未运行
) else (
    echo [INFO] GitHub Desktop正在运行，正在关闭...
    taskkill /F /IM "GitHubDesktop.exe" >nul 2>&1
    timeout /t 2 /nobreak >nul
    echo [OK] 已关闭GitHub Desktop
)
echo.
echo [步骤2] 检查配置目录
if not exist "%APPDATA%\\GitHub Desktop" (
    echo [ERROR] 配置目录不存在！
    echo.
    echo 请先手动打开GitHub Desktop一次，让它创建配置目录
    echo 然后再运行此脚本
    echo.
    pause
    exit /b 1
)
echo [OK] 配置目录存在
echo.
echo [步骤3] 备份现有配置（如果存在）
if exist "%APPDATA%\\GitHub Desktop\\config.json" (
    copy "%APPDATA%\\GitHub Desktop\\config.json" "%APPDATA%\\GitHub Desktop\\config.json.backup" >nul
    echo [OK] 已备份原配置文件
)
echo.
echo [步骤4] 创建/更新配置文件
echo 正在写入中文语言配置...
(
echo {
echo   "language": "zh-CN"
echo }
) > "%APPDATA%\\GitHub Desktop\\config.json"
echo [OK] 配置文件已创建/更新
echo.
echo [步骤5] 验证配置
echo 配置文件内容:
type "%APPDATA%\\GitHub Desktop\\config.json"
echo.
echo.
echo ========================================
echo    ✅ 修复完成！
echo ========================================
echo.
echo 重要提示:
echo 1. 配置文件已设置为中文 (language: zh-CN)
echo 2. 请手动打开GitHub Desktop
echo 3. 界面应该已经是中文了！
echo.
echo 如果还是英文，可能的原因:
echo - GitHub Desktop版本太旧不支持中文
echo - 需要完全退出后重新打开
echo - 配置文件被其他程序锁定
echo.
echo 解决方案:
echo - 右键任务栏GitHub图标，选择退出
echo - 等待10秒
echo - 重新打开GitHub Desktop
echo.
echo 按任意键退出...
pause >nul
"""
# 保存修复后的脚本
fixed_path = os.path.join(target_dir, "终极中文修复_fixed.bat")
with open(fixed_path, "w", encoding="utf-8") as f:
    f.write(fixed_script)
print(f"✅ 创建修复版脚本: {fixed_path}")
# 创建更简单的版本（避免所有输出问题）
simple_script = """@echo off
echo GitHub Desktop 中文设置 - 简单版
echo.
echo 正在设置中文界面...
echo.
REM 关闭GitHub Desktop
taskkill /F /IM "GitHubDesktop.exe" >nul 2>&1
timeout /t 2 /nobreak >nul
REM 创建配置目录
if not exist "%APPDATA%\\GitHub Desktop" (
    mkdir "%APPDATA%\\GitHub Desktop"
)
REM 写入中文配置
echo { > "%APPDATA%\\GitHub Desktop\\config.json"
echo   "language": "zh-CN" >> "%APPDATA%\\GitHub Desktop\\config.json"
echo } >> "%APPDATA%\\GitHub Desktop\\config.json"
echo 设置完成！
echo.
echo 请手动打开GitHub Desktop，界面应该是中文了。
echo.
echo 如果还是英文，请：
echo 1. 完全退出GitHub Desktop
echo 2. 删除配置文件：%APPDATA%\\GitHub Desktop\\config.json
echo 3. 重新运行此脚本
echo.
pause
"""
simple_path = os.path.join(target_dir, "简单中文设置.bat")
with open(simple_path, "w", encoding="utf-8") as f:
    f.write(simple_script)
print(f"✅ 创建简单版脚本: {simple_path}")
# 创建一键验证脚本
verify_script = """@echo off
echo GitHub Desktop 中文设置验证
echo ============================
echo.
echo 配置文件位置:
echo %APPDATA%\\GitHub Desktop\\config.json
echo.
if exist "%APPDATA%\\GitHub Desktop\\config.json" (
    echo [✓] 配置文件存在
    echo.
    echo 配置文件内容:
    echo --------------------------
    type "%APPDATA%\\GitHub Desktop\\config.json"
    echo --------------------------
    echo.
    findstr /C:"language" "%APPDATA%\\GitHub Desktop\\config.json" >nul
    if errorlevel 1 (
        echo [✗] 未找到 language 设置
    ) else (
        echo [✓] 已设置 language
    )
    findstr /C:"zh-CN" "%APPDATA%\\GitHub Desktop\\config.json" >nul
    if errorlevel 1 (
        echo [✗] 未设置为中文 (zh-CN)
    ) else (
        echo [✓] 已设置为中文 (zh-CN)
    )
) else (
    echo [✗] 配置文件不存在
    echo 请先运行设置脚本
)
echo.
echo GitHub Desktop 进程状态:
tasklist /FI "IMAGENAME eq GitHubDesktop.exe" 2>nul | find /I /N "GitHubDesktop.exe" >nul
if errorlevel 1 (
    echo [✓] GitHub Desktop 未运行
) else (
    echo [✓] GitHub Desktop 正在运行
)
echo.
pause
"""
verify_path = os.path.join(target_dir, "验证设置.bat")
with open(verify_path, "w", encoding="utf-8") as f:
    f.write(verify_script)
print(f"✅ 创建验证脚本: {verify_path}")
# 创建说明文档
explanation = """# 🔧 批处理脚本输出问题说明
## 问题现象
运行 `终极中文修复.bat` 时，输出被保存到了 `C:\\Users\\840G6\\Desktop\\123.jpg` 文件里，而不是显示在屏幕上。
## 问题原因
批处理脚本中可能包含 `>` 重定向符号，导致输出被重定向到文件而不是屏幕。
## 解决方案
我们已经创建了修复版本：
### 1. 使用修复版脚本
运行 `终极中文修复_fixed.bat` - 已修复输出问题
### 2. 使用简单版脚本
运行 `简单中文设置.bat` - 最简洁的版本
### 3. 验证设置
运行 `验证设置.bat` - 检查配置是否正确
## 操作步骤
1. **关闭 GitHub Desktop**（如果正在运行）
2. **运行 `简单中文设置.bat`**
3. **手动打开 GitHub Desktop**
4. **检查界面是否已变为中文**
## 如果还是英文
1. 运行 `验证设置.bat` 检查配置
2. 确保配置文件包含 `"language": "zh-CN"`
3. 完全退出 GitHub Desktop 后重新打开
## 配置文件位置
```
%APPDATA%\\GitHub Desktop\\config.json
```
应该包含：
```json
{
  "language": "zh-CN"
}
```
---
*修复时间：2026-04-08*
"""
explanation_path = os.path.join(target_dir, "脚本问题说明.md")
with open(explanation_path, "w", encoding="utf-8") as f:
    f.write(explanation)
print(f"✅ 创建问题说明: {explanation_path}")
# 检查桌面上的123.jpg文件
desktop_123 = r"C:\Users\840G6\Desktop\123.jpg"
if os.path.exists(desktop_123):
    file_size = os.path.getsize(desktop_123)
    print(f"\n📄 发现桌面文件: 123.jpg")
    print(f"   文件大小: {file_size} 字节")
    
    # 尝试读取内容
    try:
        with open(desktop_123, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read(500)  # 只读前500字符
        print(f"   文件内容预览: {content[:100]}...")
        
        # 如果是文本文件，重命名为.txt
        if file_size < 10000 and "echo" in content.lower():
            new_name = r"C:\Users\840G6\Desktop\123_脚本输出.txt"
            shutil.move(desktop_123, new_name)
            print(f"   已重命名为: {new_name}")
    except:
        print("   无法读取文件内容")
else:
    print("\n📄 桌面上的123.jpg文件可能已被删除或移动")
print("\n✅ 修复完成！")
print("\n🎯 推荐操作:")
print("  1. 运行 '简单中文设置.bat'")
print("  2. 手动打开GitHub Desktop")
print("  3. 检查界面是否已变为中文")
utils.set_state(success=True, 
               files_created=[
                   "终极中文修复_fixed.bat",
                   "简单中文设置.bat", 
                   "验证设置.bat",
                   "脚本问题说明.md"
               ],
               recommendation="运行'简单中文设置.bat'")