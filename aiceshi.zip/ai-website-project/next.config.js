/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['your-project.supabase.co', 'oaidalleapiprodscus.blob.core.windows.net'],
  },
  experimental: {
    serverActions: true,
  },
}
module.exports = nextConfig
