import os
import requests
import subprocess
import time
from pathlib import Path
def install_github_desktop():
    """安装中文版GitHub Desktop到指定目录"""
    
    print("🛠️ 石破天正在为您安装中文版GitHub Desktop...")
    
    # 目标安装目录
    target_dir = r"D:\软件\AI智能体\GitHub电脑版"
    
    # 创建目标目录
    os.makedirs(target_dir, exist_ok=True)
    print(f"📁 创建目标目录: {target_dir}")
    
    # GitHub Desktop 中文版下载链接
    # 使用官方GitHub Desktop安装包，安装时选择中文界面
    download_url = "https://central.github.com/deployments/desktop/desktop/latest/win32-x64"
    installer_name = "GitHubDesktopSetup-x64.exe"
    installer_path = os.path.join(target_dir, installer_name)
    
    # 检查是否已安装
    possible_paths = [
        r"C:\Users\{}\AppData\Local\GitHubDesktop".format(os.environ.get('USERNAME')),
        r"C:\Program Files\GitHub Desktop",
        r"C:\Program Files (x86)\GitHub Desktop",
        os.path.join(target_dir, "GitHub Desktop")
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"✅ GitHub Desktop 已安装于: {path}")
            print("   如需重新安装，请先卸载现有版本")
            return {
                "status": "already_installed",
                "path": path,
                "message": "GitHub Desktop 已安装，无需重复安装"
            }
    
    print("📥 正在下载 GitHub Desktop 安装包...")
    
    try:
        # 下载安装包
        response = requests.get(download_url, stream=True, timeout=30)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(installer_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        print(f"  下载进度: {progress:.1f}%", end='\r')
        
        print(f"\n✅ 下载完成: {installer_path}")
        print(f"   文件大小: {downloaded / (1024*1024):.2f} MB")
        
    except Exception as e:
        print(f"❌ 下载失败: {e}")
        print("   尝试备用下载方案...")
        
        # 备用下载链接
        backup_url = "https://github.com/shiftkey/desktop/releases/download/release-3.3.12/GitHubDesktopSetup-x64.exe"
        try:
            response = requests.get(backup_url, stream=True, timeout=30)
            response.raise_for_status()
            
            with open(installer_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            print(f"✅ 备用下载完成: {installer_path}")
            
        except Exception as e2:
            print(f"❌ 备用下载也失败: {e2}")
            return {
                "status": "download_failed",
                "error": str(e2),
                "message": "请手动下载: https://desktop.github.com/"
            }
    
    # 安装选项
    print("\n🔧 准备安装 GitHub Desktop...")
    print("   安装目录将设置为: D:\\软件\\AI智能体\\GitHub电脑版")
    
    # 创建安装脚本
    install_script = f"""
@echo off
echo 正在安装 GitHub Desktop 中文版...
echo 安装目录: {target_dir}
echo.
echo 请按照安装向导完成安装:
echo 1. 运行安装程序
echo 2. 选择安装语言为"中文(简体)"
echo 3. 安装路径选择: {target_dir}
echo 4. 完成安装并启动 GitHub Desktop
echo.
pause
start "" "{installer_path}"
"""
    
    script_path = os.path.join(target_dir, "安装说明.bat")
    with open(script_path, "w", encoding="gbk") as f:
        f.write(install_script)
    
    print(f"📝 已创建安装说明: {script_path}")
    
    # 创建快捷方式脚本
    shortcut_script = f"""
@echo off
echo 创建 GitHub Desktop 快捷方式...
echo.
REM 检查是否已安装
if exist "{target_dir}\\GitHub Desktop\\GitHubDesktop.exe" (
    echo 已找到 GitHub Desktop 主程序
    echo 创建桌面快捷方式...
    
    REM 创建桌面快捷方式
    set SCRIPT="%TEMP%\\create_shortcut.vbs"
    echo Set oWS = WScript.CreateObject("WScript.Shell") > %SCRIPT%
    echo sLinkFile = "%USERPROFILE%\\Desktop\\GitHub Desktop.lnk" >> %SCRIPT%
    echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
    echo oLink.TargetPath = "{target_dir}\\GitHub Desktop\\GitHubDesktop.exe" >> %SCRIPT%
    echo oLink.Save >> %SCRIPT%
    cscript /nologo %SCRIPT%
    del %SCRIPT%
    
    echo 创建开始菜单快捷方式...
    REM 创建开始菜单快捷方式
    set START_MENU="%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\GitHub Desktop.lnk"
    set SCRIPT2="%TEMP%\\create_startmenu.vbs"
    echo Set oWS = WScript.CreateObject("WScript.Shell") > %SCRIPT2%
    echo sLinkFile = %START_MENU% >> %SCRIPT2%
    echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT2%
    echo oLink.TargetPath = "{target_dir}\\GitHub Desktop\\GitHubDesktop.exe" >> %SCRIPT2%
    echo oLink.Save >> %SCRIPT2%
    cscript /nologo %SCRIPT2%
    del %SCRIPT2%
    
    echo.
    echo ✅ 快捷方式创建完成！
    echo 桌面和开始菜单中都可以找到 GitHub Desktop
) else (
    echo ❌ 未找到 GitHub Desktop 主程序
    echo 请先运行安装程序完成安装
)
pause
"""
    
    shortcut_path = os.path.join(target_dir, "创建快捷方式.bat")
    with open(shortcut_path, "w", encoding="gbk") as f:
        f.write(shortcut_script)
    
    print(f"🔗 已创建快捷方式脚本: {shortcut_path}")
    
    # 创建使用说明文档
    usage_guide = f"""# GitHub Desktop 中文版使用指南
## 📍 安装位置
{D:\\软件\\AI智能体\\GitHub电脑版}
## 🚀 如何安装
1. 双击运行 `安装说明.bat`
2. 按照向导完成安装
3. 安装时选择**中文(简体)**语言
4. 安装路径选择: `{target_dir}`
## 🔗 创建快捷方式
安装完成后，运行 `创建快捷方式.bat` 在桌面和开始菜单创建快捷方式
## 📖 基本使用步骤
### 1. 登录 GitHub 账号
- 打开 GitHub Desktop
- 点击 "Sign in to GitHub.com"
- 输入你的 GitHub 账号密码
### 2. 克隆我们的 AI 网站项目
1. 点击 "Clone a repository"
2. 选择 "URL" 标签
3. 输入项目地址: `https://github.com/你的用户名/ai-website-platform.git`
4. 选择本地保存路径
5. 点击 "Clone"
### 3. 日常开发工作流
```
拉取最新代码 → 修改代码 → 提交更改 → 推送到GitHub
```
### 4. 与 Vercel 集成
- 每次推送到 `main` 分支
- Vercel 自动检测并重新部署
- 网站自动更新上线
## ⚙️ 配置中文界面
如果安装后不是中文界面：
1. 点击菜单 File → Options
2. 选择 Appearance 标签
3. 在 Language 下拉框选择 "简体中文"
4. 重启 GitHub Desktop
## 🔧 常用快捷键
- `Ctrl+Shift+N` - 新建仓库
- `Ctrl+Shift+O` - 打开仓库
- `Ctrl+P` - 推送更改
- `Ctrl+Shift+P` - 拉取最新代码
- `Ctrl+Enter` - 提交更改
## 📞 遇到问题
1. 检查网络连接
2. 确认 GitHub 账号密码正确
3. 查看错误日志: Help → Show Logs in Explorer
4. 重新安装: 先卸载再重新安装
## 🎯 为 AI 网站项目特别配置
1. 设置默认分支为 `main`
2. 配置 Git 用户名邮箱:
   ```
   git config --global user.name "你的名字"
   git config --global user.email "你的邮箱"
   ```
3. 启用自动换行: `git config --global core.autocrlf true`
---
*安装时间: {time.strftime("%Y-%m-%d %H:%M:%S")}*
*由 AiPy 小章鱼团队为您配置*
"""
    
    guide_path = os.path.join(target_dir, "使用指南.md")
    with open(guide_path, "w", encoding="utf-8") as f:
        f.write(usage_guide)
    
    print(f"📚 已创建使用指南: {guide_path}")
    
    # 尝试自动运行安装程序
    print("\n🚀 尝试自动启动安装程序...")
    try:
        # 使用 subprocess 运行安装程序
        subprocess.Popen([installer_path], shell=True)
        print("✅ 安装程序已启动，请按照向导完成安装")
        print("   注意选择: 中文语言 + 指定安装目录")
        
        # 等待几秒让安装程序启动
        time.sleep(3)
        
    except Exception as e:
        print(f"⚠️ 自动启动失败: {e}")
        print(f"   请手动双击运行: {installer_path}")
    
    # 总结信息
    print("\n" + "="*60)
    print("✅ GitHub Desktop 中文版安装准备完成！")
    print("="*60)
    print(f"📁 安装目录: {target_dir}")
    print(f"📦 安装包: {installer_name}")
    print(f"📝 安装说明: 安装说明.bat")
    print(f"🔗 快捷方式: 创建快捷方式.bat")
    print(f"📚 使用指南: 使用指南.md")
    print("\n🎯 下一步操作:")
    print("1. 按照安装向导完成安装（选择中文语言）")
    print("2. 安装后运行'创建快捷方式.bat'")
    print("3. 打开GitHub Desktop登录你的GitHub账号")
    print("4. 克隆我们的AI网站项目开始开发！")
    print("="*60)
    
    # 返回安装信息
    return {
        "status": "ready_to_install",
        "target_directory": target_dir,
        "installer_path": installer_path,
        "guide_path": guide_path,
        "files_created": [
            "安装说明.bat",
            "创建快捷方式.bat", 
            "使用指南.md",
            installer_name
        ],
        "next_steps": [
            "运行安装程序完成安装",
            "选择中文语言界面",
            "设置安装路径为指定目录",
            "登录GitHub账号",
            "克隆AI网站项目"
        ]
    }
if __name__ == "__main__":
    result = install_github_desktop()
    utils.set_state(success=True, result=result)