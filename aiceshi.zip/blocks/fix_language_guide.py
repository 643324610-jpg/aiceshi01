import os
from pathlib import Path
target_dir = r"D:\软件\AI智能体\GitHub电脑版"
os.makedirs(target_dir, exist_ok=True)
# 更新设置中文的完整指南（针对新版本GitHub Desktop）
guide_content = """# 📝 GitHub Desktop 新版本设置中文界面完整指南
## 🚨 重要说明
在最新版 GitHub Desktop 中，**语言设置位置已经改了**！
老版本在 `File → Options → Appearance`，**新版本位置变了！**
## ✅ 正确步骤（新版本 GitHub Desktop ≥ 3.3）
### 方法一：界面操作法（推荐）
1. **打开 GitHub Desktop**
2. 点击左上角菜单 **`File`（文件）**
3. 在下拉菜单最下面找到 **`Preferences...`（偏好设置）**  
   ⚠️ **注意！不是 Options！新版本叫 Preferences！**
4. 在弹出的偏好设置窗口中，点击左侧 **`Appearance`（外观）**
5. 在右侧找到 **`Language`（语言）**下拉框
6. 选择 **`简体中文`** 或者 **`Chinese (Simplified)`**
7. 点击 **`Save`（保存）**
8. **关闭 GitHub Desktop，重新打开**，界面就是中文了！🎉
### 方法二：配置文件法（直接改配置文件，更快）
如果界面上找不到 Language 选项，直接改配置文件：
1. 关闭 GitHub Desktop
2. 打开以下目录：
   ```
   %APPDATA%\\GitHub Desktop
   ```
   在文件资源管理器地址栏直接复制粘贴上面的路径回车就能打开
3. 找到文件 `config.json`
4. 用记事本打开 `config.json`
5. 在最外层添加一行（如果已经有 `language` 键就修改它）：
   ```json
   "language": "zh-CN",
   ```
6. 保存文件，重新打开 GitHub Desktop，就是中文了！✅
**示例 config.json 应该像这样：**
```json
{
  "language": "zh-CN",
  "theme": "system",
  ... 其他配置保持不变 ...
}
```
### 方法三：命令行一键设置（最简单）
双击运行这个批处理文件，自动设置中文：
`一键设置中文.bat`
运行完重启 GitHub Desktop 就行了！
## 📸 完整图文步骤
### 第一步：打开偏好设置
```
GitHub Desktop 主界面 → 左上角 File → Preferences
```
截图指引（文字版）：
```
┌─────────────────────────────────────┐
│ File  Edit  View  Repository  Help   │
│  ┌───────────────────────────────┐  │
│  │ New Repository...              │  │
│  │ Add Local Repository...        │  │
│  │ Clone Repository...            │  │
│  │ ...                           │  │
│  │ Preferences...            ← 在这里！│
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
```
### 第二步：在 Appearance 找到 Language
```
Preferences 窗口 → 左侧点击 Appearance → 右侧 Language 下拉框 → 选择简体中文
```
### 第三步：保存重启
- 点击 Save
- 关闭 GitHub Desktop
- 重新打开，完成！
## ❓ 常见问题
### Q1: 还是找不到 Language 下拉框？
**A:** 说明你的 GitHub Desktop 是旧版本，或者是自动更新问题。直接用**方法二**改配置文件，100%成功！
### Q2: 改完配置文件还是英文？
**A:** 
1. 确认你改的配置文件路径正确：`%APPDATA%\GitHub Desktop\config.json`
2. 确认 JSON 格式正确（逗号不要漏也不要多）
3. 完全退出 GitHub Desktop（任务栏图标右键退出），再重新打开
4. 如果还是不行，删除整个 `%APPDATA%\GitHub Desktop` 文件夹，重启 GitHub Desktop 重新配置
### Q3: 改完变成中文了，怎么改回英文？
**A:** 同样方法，把 `zh-CN` 改成 `en-US` 就行！
## 🔧 一键修复脚本
我们已经为你准备好了一键设置中文的脚本，直接双击运行就行！
文件位置：`D:\软件\AI智能体\GitHub电脑版\一键设置中文.bat`
---
*更新时间：2026-04-08*
*针对 GitHub Desktop 新版本 ≥ 3.0*
"""
# 保存新指南
guide_path = os.path.join(target_dir, "GitHub设置中文指南.md")
with open(guide_path, "w", encoding="utf-8") as f:
    f.write(guide_content)
print(f"✅ 更新中文设置指南: {guide_path}")
# 创建一键设置中文的批处理脚本
oneclick_script = """@echo off
echo ========================================
echo    GitHub Desktop 一键设置中文
echo ========================================
echo.
echo 正在设置 GitHub Desktop 界面为简体中文...
echo.
REM 获取配置文件路径
set CONFIG_PATH=%APPDATA%\\GitHub Desktop\\config.json
echo 配置文件路径: %CONFIG_PATH%
echo.
REM 检查目录是否存在
if not exist "%APPDATA%\\GitHub Desktop" (
    echo [INFO] GitHub Desktop 配置目录不存在
    echo 请先打开一次 GitHub Desktop 再运行此脚本
    pause
    exit /b 1
)
REM 检查配置文件是否存在
if not exist "%CONFIG_PATH%" (
    echo [INFO] 配置文件不存在，创建新配置文件
    echo { > "%CONFIG_PATH%"
    echo   "language": "zh-CN" >> "%CONFIG_PATH%"
    echo } >> "%CONFIG_PATH%"
    echo [OK] 已创建配置文件并设置语言为中文
    echo.
    echo 请关闭 GitHub Desktop 再重新打开，界面就是中文了！
    pause
    exit /b 0
)
echo [OK] 找到现有配置文件
echo.
REM 使用 PowerShell 修改配置文件
powershell -Command "$content = Get-Content -Path '%CONFIG_PATH%' -Raw -Encoding UTF8; $json = $content | ConvertFrom-Json; $json | Add-Member -MemberType NoteProperty -Name 'language' -Value 'zh-CN' -Force; $json | ConvertTo-Json -Depth 10 | Set-Content -Path '%CONFIG_PATH%' -Encoding UTF8; Write-Host '✅ 修改成功'"
echo.
echo ========================================
echo    ✅ 设置完成！
echo ========================================
echo.
echo 下一步:
echo 1. 完全关闭 GitHub Desktop（任务栏图标右键退出）
echo 2. 重新打开 GitHub Desktop
echo 3. 现在界面应该就是简体中文了！
echo.
echo 如果还是英文，请查看完整指南: GitHub设置中文指南.md
echo.
pause
"""
oneclick_path = os.path.join(target_dir, "一键设置中文.bat")
with open(oneclick_path, "w", encoding="utf-8") as f:
    f.write(oneclick_script)
print(f"✅ 创建一键设置中文脚本: {oneclick_path}")
# 更新快速启动菜单，加上设置中文选项
# 读取原来的菜单
old_menu_path = os.path.join(target_dir, "快速启动菜单.bat")
old_menu_content = ""
if os.path.exists(old_menu_path):
    with open(old_menu_path, "r", encoding="utf-8") as f:
        old_menu_content = f.read()
# 添加设置中文选项
new_menu_content = old_menu_content.replace(
"""echo [6] 启动命令行
echo [7] 退出
""",
"""echo [6] 一键设置中文界面
echo [7] 启动命令行
echo [8] 退出
"""
).replace(
"""if "%choice%"=="6" goto start_cmd
if "%choice%"=="7" goto exit
""",
"""if "%choice%"=="6" goto set_chinese
if "%choice%"=="7" goto start_cmd
if "%choice%"=="8" goto exit
"""
).replace(
""":start_cmd
echo 启动命令行...
start cmd /k "cd /d {target_dir} && echo AI网站开发环境已就绪"
goto menu
:exit
echo 再见！
exit /b 0
""",
""":set_chinese
echo 一键设置中文界面...
call "{target_dir}\\一键设置中文.bat"
goto menu
:start_cmd
echo 启动命令行...
start cmd /k "cd /d {target_dir} && echo AI网站开发环境已就绪"
goto menu
:exit
echo 再见！
exit /b 0
"""
)
# 格式化路径
new_menu_content = new_menu_content.replace("{target_dir}", target_dir.replace("\\", "\\\\"))
# 保存更新后的菜单
with open(old_menu_path, "w", encoding="utf-8") as f:
    f.write(new_menu_content)
print(f"✅ 更新快速启动菜单: {old_menu_path}")
# 验证并输出结果
result = {
    "status": "success",
    "fix": "新版本GitHub Desktop语言位置变更",
    "files_created": [
        "GitHub设置中文指南.md",
        "一键设置中文.bat",
        "快速启动菜单.bat (已更新)"
    ],
    "guide_path": guide_path,
    "oneclick_path": oneclick_path,
    "solution": "新版本GitHub Desktop语言设置在 File → Preferences → Appearance，不是Options了"
}
print("\n✅ 修复完成！")
print("\n📋 修复内容:")
print("  - 更新了设置中文指南，适配新版本GitHub Desktop")
print("  - 创建了一键设置中文脚本")
print("  - 更新了快速启动菜单，增加设置中文选项")
print("\n🎯 最简单方法:")
print("  1. 双击运行 '一键设置中文.bat'")
print("  2. 关闭GitHub Desktop再重新打开")
print("  3. 界面就是中文了！")
utils.set_state(success=True, result=result)