import json
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import numpy as np
def create_development_roadmap():
    """创建详细的开发路线图"""
    
    # 读取架构分析结果
    with open("architecture_analysis.json", "r", encoding="utf-8") as f:
        architecture_data = json.load(f)
    
    # 开发路线图详情
    roadmap_details = {
        "项目概述": {
            "项目名称": "AI多功能网站平台",
            "技术栈": "Next.js 14+ + Supabase + AI APIs + 微信支付宝支付 + Vercel",
            "目标用户": "需要AI创作能力的个人用户、内容创作者、中小企业",
            "核心价值": "一站式AI创作平台，集成聊天、画图、视频生成能力"
        },
        "阶段一：项目初始化 (第1-2周)": {
            "目标": "搭建基础开发环境，配置核心依赖",
            "任务": [
                {"id": "T1-1", "任务": "初始化Next.js项目", "负责人": "步惊云", "工时": "2天", "依赖": "无"},
                {"id": "T1-2", "任务": "TypeScript配置", "负责人": "步惊云", "工时": "1天", "依赖": "T1-1"},
                {"id": "T1-3", "任务": "Supabase项目创建", "负责人": "夜辰", "工时": "1天", "依赖": "无"},
                {"id": "T1-4", "任务": "环境变量配置", "负责人": "夜辰", "工时": "1天", "依赖": "T1-1,T1-3"},
                {"id": "T1-5", "任务": "基础页面结构设计", "负责人": "步惊云", "工时": "3天", "依赖": "T1-1"},
                {"id": "T1-6", "任务": "UI组件库搭建", "负责人": "步惊云", "工时": "2天", "依赖": "T1-5"}
            ],
            "交付物": [
                "可运行的Next.js项目",
                "Supabase连接配置",
                "基础页面模板",
                "项目文档结构"
            ]
        },
        "阶段二：核心功能开发 (第3-6周)": {
            "目标": "实现用户系统和基础AI功能",
            "任务": [
                {"id": "T2-1", "任务": "用户认证系统", "负责人": "夜辰", "工时": "3天", "依赖": "T1-3"},
                {"id": "T2-2", "任务": "数据库设计", "负责人": "夜辰", "工时": "2天", "依赖": "T1-3"},
                {"id": "T2-3", "任务": "API路由设计", "负责人": "夜辰", "工时": "2天", "依赖": "T2-1"},
                {"id": "T2-4", "任务": "OpenAI API集成", "负责人": "白若溪", "工时": "3天", "依赖": "T2-3"},
                {"id": "T2-5", "任务": "聊天界面开发", "负责人": "步惊云", "工时": "4天", "依赖": "T2-4"},
                {"id": "T2-6", "任务": "Stable Diffusion集成", "负责人": "白若溪", "工时": "3天", "依赖": "T2-3"},
                {"id": "T2-7", "任务": "图像生成界面", "负责人": "步惊云", "工时": "3天", "依赖": "T2-6"},
                {"id": "T2-8", "任务": "支付接口设计", "负责人": "柳如烟", "工时": "2天", "依赖": "T2-1"}
            ],
            "交付物": [
                "完整的用户注册登录系统",
                "AI聊天功能",
                "图像生成功能",
                "支付接口原型"
            ]
        },
        "阶段三：高级功能集成 (第7-9周)": {
            "目标": "集成视频生成和支付功能",
            "任务": [
                {"id": "T3-1", "任务": "视频生成API集成", "负责人": "白若溪", "工时": "4天", "依赖": "T2-3"},
                {"id": "T3-2", "任务": "视频编辑界面", "负责人": "步惊云", "工时": "3天", "依赖": "T3-1"},
                {"id": "T3-3", "任务": "微信支付接入", "负责人": "柳如烟", "工时": "3天", "依赖": "T2-8"},
                {"id": "T3-4", "任务": "支付宝接入", "负责人": "柳如烟", "工时": "2天", "依赖": "T2-8"},
                {"id": "T3-5", "任务": "支付回调处理", "负责人": "夜辰", "工时": "2天", "依赖": "T3-3,T3-4"},
                {"id": "T3-6", "任务": "订单管理系统", "负责人": "夜辰", "工时": "3天", "依赖": "T3-5"},
                {"id": "T3-7", "任务": "Vercel部署配置", "负责人": "石破天", "工时": "2天", "依赖": "T2-1"}
            ],
            "交付物": [
                "视频生成功能",
                "完整的支付系统",
                "订单管理后台",
                "生产环境部署配置"
            ]
        },
        "阶段四：优化与上线 (第10-12周)": {
            "目标": "性能优化、测试和正式上线",
            "任务": [
                {"id": "T4-1", "任务": "性能优化", "负责人": "步惊云", "工时": "3天", "依赖": "T3-7"},
                {"id": "T4-2", "任务": "安全加固", "负责人": "夜辰", "工时": "2天", "依赖": "T3-7"},
                {"id": "T4-3", "任务": "单元测试", "负责人": "白若溪", "工时": "3天", "依赖": "T3-7"},
                {"id": "T4-4", "任务": "集成测试", "负责人": "柳如烟", "工时": "2天", "依赖": "T4-3"},
                {"id": "T4-5", "任务": "用户测试", "负责人": "石破天", "工时": "3天", "依赖": "T4-4"},
                {"id": "T4-6", "任务": "文档编写", "负责人": "所有人", "工时": "2天", "依赖": "T4-5"},
                {"id": "T4-7", "任务": "正式上线", "负责人": "石破天", "工时": "1天", "依赖": "T4-6"},
                {"id": "T4-8", "任务": "监控配置", "负责人": "夜辰", "工时": "1天", "依赖": "T4-7"}
            ],
            "交付物": [
                "优化后的生产版本",
                "完整的测试报告",
                "用户手册和API文档",
                "线上监控系统"
            ]
        },
        "资源分配": {
            "人员配置": {
                "前端开发": {"人员": "步惊云", "投入": "80%"},
                "后端开发": {"人员": "夜辰", "投入": "70%"},
                "AI集成": {"人员": "白若溪", "投入": "60%"},
                "支付集成": {"人员": "柳如烟", "投入": "50%"},
                "部署运维": {"人员": "石破天", "投入": "40%"},
                "项目管理": {"人员": "AiPy小章鱼", "投入": "30%"}
            },
            "里程碑": [
                {"名称": "MVP版本", "时间": "第6周末", "目标": "基础AI聊天和图像生成"},
                {"名称": "Beta版本", "时间": "第9周末", "目标": "完整支付和视频功能"},
                {"名称": "正式版", "时间": "第12周末", "目标": "优化上线"}
            ]
        },
        "风险管理": {
            "技术风险": [
                {"风险": "AI API成本超预期", "应对": "设置使用限额，监控API调用"},
                {"风险": "支付合规问题", "应对": "提前咨询支付服务商，确保合规"},
                {"风险": "性能瓶颈", "应对": "早期性能测试，使用CDN缓存"}
            ],
            "进度风险": [
                {"风险": "第三方API变更", "应对": "封装API层，准备备用方案"},
                {"风险": "人员变动", "应对": "文档规范化，代码审查制度"}
            ]
        }
    }
    
    # 保存路线图
    with open("development_roadmap.json", "w", encoding="utf-8") as f:
        json.dump(roadmap_details, f, ensure_ascii=False, indent=2)
    
    # 创建甘特图
    create_gantt_chart(roadmap_details)
    
    print("✅ 开发路线图已生成！")
    print("📊 总开发周期：12周")
    print("👥 团队规模：6人")
    print("💾 保存文件：")
    print("   - development_roadmap.json (详细路线图)")
    print("   - roadmap_gantt.png (甘特图)")
    
    return roadmap_details
def create_gantt_chart(roadmap_data):
    """创建开发路线甘特图"""
    
    # 设置中文字体
    from matplotlib import font_manager
    font_path = "SourceHanSansCN-Regular.otf"
    font_manager.fontManager.addfont(font_path)
    prop = font_manager.FontProperties(fname=font_path)
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.family'] = prop.get_name()
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(14, 10))
    
    # 阶段数据
    phases = ["阶段一", "阶段二", "阶段三", "阶段四"]
    phase_colors = ['#3498db', '#2ecc71', '#9b59b6', '#e74c3c']
    
    # 任务数据
    tasks = []
    colors = []
    start_weeks = []
    durations = []
    
    # 阶段一任务
    tasks.append("项目初始化")
    colors.append(phase_colors[0])
    start_weeks.append(0)
    durations.append(2)
    
    # 阶段二任务
    tasks.append("核心功能开发")
    colors.append(phase_colors[1])
    start_weeks.append(2)
    durations.append(4)
    
    # 阶段三任务
    tasks.append("高级功能集成")
    colors.append(phase_colors[2])
    start_weeks.append(6)
    durations.append(3)
    
    # 阶段四任务
    tasks.append("优化与上线")
    colors.append(phase_colors[3])
    start_weeks.append(9)
    durations.append(3)
    
    # 里程碑
    milestones = [
        {"name": "MVP版本", "week": 6, "color": "#f39c12"},
        {"name": "Beta版本", "week": 9, "color": "#e67e22"},
        {"name": "正式上线", "week": 12, "color": "#d35400"}
    ]
    
    # 绘制甘特图
    y_pos = np.arange(len(tasks))
    
    # 任务条
    bars = ax.barh(y_pos, durations, left=start_weeks, 
                   height=0.6, color=colors, alpha=0.8,
                   edgecolor='white', linewidth=2)
    
    # 添加任务标签
    for i, (task, start, duration) in enumerate(zip(tasks, start_weeks, durations)):
        ax.text(start + duration/2, i, task, 
                ha='center', va='center', 
                fontweight='bold', color='white',
                fontsize=11)
    
    # 添加里程碑
    for milestone in milestones:
        ax.axvline(x=milestone["week"], color=milestone["color"], 
                  linestyle='--', linewidth=2, alpha=0.7)
        ax.text(milestone["week"], len(tasks)-0.5, milestone["name"],
                ha='center', va='bottom', color=milestone["color"],
                fontweight='bold', fontsize=10,
                bbox=dict(boxstyle="round,pad=0.3", 
                         facecolor='white', 
                         edgecolor=milestone["color"]))
    
    # 设置坐标轴
    ax.set_yticks(y_pos)
    ax.set_yticklabels(tasks, fontsize=12)
    ax.set_xlabel('开发周数', fontsize=12)
    ax.set_title('AI网站平台开发路线图', fontsize=16, fontweight='bold', pad=20)
    
    # 网格线
    ax.grid(True, axis='x', alpha=0.3, linestyle='--')
    
    # 图例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=phase_colors[0], alpha=0.8, label='项目初始化 (2周)'),
        Patch(facecolor=phase_colors[1], alpha=0.8, label='核心功能开发 (4周)'),
        Patch(facecolor=phase_colors[2], alpha=0.8, label='高级功能集成 (3周)'),
        Patch(facecolor=phase_colors[3], alpha=0.8, label='优化与上线 (3周)'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图片
    plt.savefig('roadmap_gantt.png', dpi=300, bbox_inches='tight',
                facecolor=fig.get_facecolor())
    
    plt.close()
if __name__ == "__main__":
    roadmap = create_development_roadmap()
    utils.set_state(success=True, result=roadmap)