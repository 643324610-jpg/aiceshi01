import os
import json
import shutil
from pathlib import Path
def fix_and_create_project_structure():
    """修复并创建完整的项目文档结构"""
    
    print("🔧 夜辰正在修复项目文档结构...")
    
    # 清理可能存在的错误目录
    project_root = "ai-website-project"
    if os.path.exists(project_root):
        try:
            shutil.rmtree(project_root)
            print("   🗑️ 清理旧目录")
        except Exception as e:
            print(f"   ⚠️ 清理失败: {e}")
    
    # 重新创建项目结构
    os.makedirs(project_root, exist_ok=True)
    print(f"   📂 创建项目根目录: {project_root}")
    
    # 创建核心目录结构
    core_directories = [
        "docs/architecture",
        "docs/requirements", 
        "docs/design",
        "docs/api",
        "docs/deployment",
        "src/app/api/auth",
        "src/app/api/chat",
        "src/app/api/image", 
        "src/app/api/video",
        "src/app/api/payment",
        "src/app/api/webhook",
        "src/app/(auth)/login",
        "src/app/(auth)/register",
        "src/app/(auth)/callback",
        "src/app/(dashboard)/chat",
        "src/app/(dashboard)/image",
        "src/app/(dashboard)/video",
        "src/app/(dashboard)/billing",
        "src/app/(dashboard)/profile",
        "src/app/(admin)/users",
        "src/app/(admin)/content",
        "src/app/(admin)/analytics",
        "src/app/(admin)/settings",
        "src/components/ui",
        "src/components/layout",
        "src/components/chat",
        "src/components/image",
        "src/components/video",
        "src/components/payment",
        "src/lib/supabase",
        "src/lib/openai",
        "src/lib/payment",
        "src/lib/utils",
        "src/lib/types",
        "src/styles/themes",
        "src/hooks",
        "src/store",
        "public/images",
        "public/fonts",
        "public/icons",
        "tests/unit",
        "tests/integration",
        "tests/fixtures",
        "scripts",
        "config"
    ]
    
    # 创建所有目录
    for dir_path in core_directories:
        full_path = os.path.join(project_root, dir_path)
        os.makedirs(full_path, exist_ok=True)
        print(f"   📂 创建目录: {dir_path}")
    
    # 创建关键文件
    key_files = {
        "README.md": """# AI多功能网站平台
## 项目概述
基于Next.js + Supabase + AI APIs + 微信支付宝支付 + Vercel的一站式AI创作平台。
## 技术栈
- **前端**: Next.js 14+ (App Router), React, TypeScript, Tailwind CSS
- **后端**: Next.js API Routes, Supabase (PostgreSQL, Auth, Storage)
- **AI服务**: OpenAI API, Stable Diffusion, RunwayML/Sora API
- **支付**: 微信支付, 支付宝
- **部署**: Vercel (Serverless, CDN, Edge Functions)
- **监控**: Vercel Analytics, Sentry, Logtail
## 功能特性
1. 🤖 AI聊天对话 (GPT-4)
2. 🎨 图像生成 (DALL-E 3, Stable Diffusion)
3. 🎬 视频生成 (Sora API, RunwayML)
4. 💳 支付系统 (微信/支付宝)
5. 👤 用户系统 (注册/登录/订阅)
6. 📊 管理后台 (用户/内容/财务)
## 快速开始
```bash
# 克隆项目
git clone <repository-url>
# 安装依赖
npm install
# 环境配置
cp .env.example .env.local
# 启动开发服务器
npm run dev
```
## 开发指南
详细开发文档请查看 `docs/` 目录。
## 部署
项目已配置Vercel一键部署，支持自动CI/CD。
## 许可证
MIT License
""",
        
        "docs/architecture/system-architecture.md": """# 系统架构设计
## 架构概览
```
用户层 (Next.js前端) → 应用层 (API Routes) → 服务层 (AI/支付) → 数据层 (Supabase)
```
## 技术选型说明
### 前端架构
- **Next.js 14+**: 支持SSR/SSG/ISR，App Router提供更好的路由体验
- **TypeScript**: 类型安全，提高代码质量
- **Tailwind CSS**: 原子化CSS，快速UI开发
### 后端架构
- **Supabase**: 完整的BaaS解决方案，包含数据库、认证、存储
- **Next.js API Routes**: 前后端一体化，减少上下文切换
- **Serverless Functions**: 按需扩展，成本优化
### AI集成
- **OpenAI API**: GPT-4聊天，DALL-E 3图像生成
- **Stable Diffusion**: 开源图像生成，成本可控
- **RunwayML/Sora**: 视频生成能力
### 支付集成
- **微信支付**: 国内主流支付方式
- **支付宝**: 覆盖广泛用户群体
- **聚合支付**: 统一支付接口，简化集成
## 数据流设计
1. 用户请求 → Next.js前端
2. 前端调用API Routes
3. API调用Supabase/AI服务
4. 返回结果给用户
""",
        
        ".env.example": """# 环境变量配置
# 复制此文件为 .env.local 并填写实际值
# Supabase配置
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
# OpenAI配置
OPENAI_API_KEY=sk-your-openai-api-key
OPENAI_ORGANIZATION=org-your-org-id
# 图像生成配置
STABLE_DIFFUSION_API_KEY=your-stable-diffusion-key
STABLE_DIFFUSION_API_URL=https://api.stability.ai
# 视频生成配置
RUNWAYML_API_KEY=your-runwayml-key
SORA_API_KEY=your-sora-key
# 支付配置
WECHAT_APP_ID=your-wechat-app-id
WECHAT_MCH_ID=your-wechat-merchant-id
WECHAT_API_KEY=your-wechat-api-key
ALIPAY_APP_ID=your-alipay-app-id
ALIPAY_PRIVATE_KEY=your-alipay-private-key
ALIPAY_PUBLIC_KEY=your-alipay-public-key
# 其他配置
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=http://localhost:3000
# 部署配置
VERCEL_PROJECT_ID=your-vercel-project-id
VERCEL_TEAM_ID=your-vercel-team-id
""",
        
        "package.json": """{
  "name": "ai-website-platform",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "test": "jest",
    "test:e2e": "playwright test",
    "deploy": "vercel --prod"
  },
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@supabase/supabase-js": "^2.39.0",
    "openai": "^4.0.0",
    "next-auth": "^4.24.0",
    "tailwindcss": "^3.3.0",
    "zustand": "^4.4.0",
    "axios": "^1.6.0",
    "date-fns": "^2.30.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "typescript": "^5.0.0",
    "jest": "^29.0.0",
    "@testing-library/react": "^14.0.0",
    "playwright": "^1.40.0",
    "eslint": "^8.0.0",
    "prettier": "^3.0.0"
  }
}
""",
        
        "next.config.js": """/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['your-project.supabase.co', 'oaidalleapiprodscus.blob.core.windows.net'],
  },
  experimental: {
    serverActions: true,
  },
}
module.exports = nextConfig
""",
        
        "tailwind.config.js": """/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
"""
    }
    
    # 创建关键文件
    for file_path, content in key_files.items():
        full_path = os.path.join(project_root, file_path)
        
        # 确保目录存在
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"   📄 创建文件: {file_path}")
    
    # 创建占位文件
    placeholder_files = [
        "docs/architecture/database-design.md",
        "docs/architecture/api-design.md",
        "docs/requirements/business-requirements.md",
        "docs/requirements/functional-spec.md",
        "docs/requirements/non-functional-spec.md",
        "docs/design/ui-design.md",
        "docs/design/ux-flow.md",
        "docs/design/component-design.md",
        "docs/api/openapi-spec.yaml",
        "docs/api/api-reference.md",
        "docs/api/webhook-spec.md",
        "docs/deployment/deployment-guide.md",
        "docs/deployment/env-config.md",
        "docs/deployment/monitoring-setup.md",
        
        "src/app/api/auth/route.ts",
        "src/app/api/auth/types.ts",
        "src/app/api/chat/route.ts",
        "src/app/api/chat/types.ts",
        "src/app/api/image/route.ts",
        "src/app/api/image/types.ts",
        "src/app/api/video/route.ts",
        "src/app/api/video/types.ts",
        "src/app/api/payment/route.ts",
        "src/app/api/payment/types.ts",
        "src/app/api/webhook/route.ts",
        "src/app/api/webhook/types.ts",
        
        "src/app/(auth)/login/page.tsx",
        "src/app/(auth)/login/layout.tsx",
        "src/app/(auth)/register/page.tsx",
        "src/app/(auth)/register/layout.tsx",
        "src/app/(auth)/callback/page.tsx",
        "src/app/(auth)/callback/layout.tsx",
        
        "src/app/globals.css",
        "src/app/layout.tsx",
        "src/app/page.tsx",
        
        "src/components/ui/button.tsx",
        "src/components/ui/input.tsx",
        "src/components/ui/card.tsx",
        "src/components/ui/modal.tsx",
        "src/components/ui/table.tsx",
        
        "src/lib/supabase/client.ts",
        "src/lib/supabase/auth.ts",
        "src/lib/supabase/database.ts",
        "src/lib/supabase/storage.ts",
        
        "config/tsconfig.json",
        "config/.gitignore"
    ]
    
    for file_path in placeholder_files:
        full_path = os.path.join(project_root, file_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        Path(full_path).touch()
        print(f"     📄 创建占位文件: {file_path}")
    
    # 统计信息
    total_dirs = sum(1 for _ in os.walk(project_root))
    total_files = sum(len(files) for _, _, files in os.walk(project_root))
    
    print(f"\n✅ 项目文档结构修复完成！")
    print(f"📁 项目根目录: {project_root}")
    print(f"📊 总目录数: {total_dirs}")
    print(f"📄 总文件数: {total_files}")
    
    # 生成结构报告
    structure_report = {
        "project_name": "AI多功能网站平台",
        "project_path": os.path.abspath(project_root),
        "total_directories": total_dirs,
        "total_files": total_files,
        "main_directories": [
            "docs/ - 项目文档 (架构/需求/设计/API/部署)",
            "src/ - 源代码 (App Router/组件/工具库/样式)",
            "public/ - 静态资源 (图片/字体/图标)",
            "tests/ - 测试文件 (单元/集成/E2E)",
            "config/ - 配置文件 (Next.js/Tailwind/TypeScript)"
        ],
        "key_files_created": [
            "README.md - 项目说明文档",
            "docs/architecture/system-architecture.md - 系统架构设计",
            ".env.example - 环境变量配置示例",
            "package.json - 项目依赖配置",
            "next.config.js - Next.js配置",
            "tailwind.config.js - Tailwind CSS配置"
        ],
        "technology_stack": {
            "frontend": "Next.js 14+, React, TypeScript, Tailwind CSS",
            "backend": "Supabase (PostgreSQL, Auth, Storage)",
            "ai_services": "OpenAI API, Stable Diffusion, RunwayML/Sora",
            "payment": "微信支付, 支付宝",
            "deployment": "Vercel (Serverless, CDN)",
            "monitoring": "Vercel Analytics, Sentry"
        },
        "created_at": "2026-04-08",
        "status": "修复完成，结构完整"
    }
    
    with open("project_structure_fixed.json", "w", encoding="utf-8") as f:
        json.dump(structure_report, f, ensure_ascii=False, indent=2)
    
    print(f"📋 结构报告: project_structure_fixed.json")
    
    return structure_report
if __name__ == "__main__":
    report = fix_and_create_project_structure()
    utils.set_state(success=True, 
                   project_path="ai-website-project",
                   report=report,
                   message="项目文档结构已成功修复并创建")