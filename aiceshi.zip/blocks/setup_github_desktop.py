import os
import shutil
import subprocess
import json
def setup_github_desktop():
    """为已安装的GitHub Desktop创建快捷方式和配置"""
    
    print("🔧 石破天正在为您配置GitHub Desktop...")
    
    # 目标目录
    target_dir = r"D:\软件\AI智能体\GitHub电脑版"
    
    # 创建目标目录
    os.makedirs(target_dir, exist_ok=True)
    print(f"📁 创建目录: {target_dir}")
    
    # 查找已安装的GitHub Desktop
    installed_paths = [
        r"C:\Users\{}\AppData\Local\GitHubDesktop\GitHubDesktop.exe".format(os.environ.get('USERNAME')),
        r"C:\Program Files\GitHub Desktop\GitHubDesktop.exe",
        r"C:\Program Files (x86)\GitHub Desktop\GitHubDesktop.exe",
    ]
    
    github_exe = None
    for path in installed_paths:
        if os.path.exists(path):
            github_exe = path
            print(f"✅ 找到GitHub Desktop: {path}")
            break
    
    if not github_exe:
        print("❌ 未找到GitHub Desktop可执行文件")
        return {"status": "not_found"}
    
    # 1. 创建桌面快捷方式
    print("\n🔗 创建桌面快捷方式...")
    desktop_shortcut = os.path.join(os.path.expanduser("~"), "Desktop", "GitHub Desktop.lnk")
    
    # 创建VBS脚本创建快捷方式
    shortcut_vbs = f"""
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{desktop_shortcut}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{github_exe}"
oLink.WorkingDirectory = "{os.path.dirname(github_exe)}"
oLink.Description = "GitHub Desktop 中文版"
oLink.Save
"""
    
    vbs_path = os.path.join(target_dir, "create_desktop_shortcut.vbs")
    with open(vbs_path, "w", encoding="gbk") as f:
        f.write(shortcut_vbs)
    
    # 运行VBS脚本
    try:
        subprocess.run(['cscript', '//nologo', vbs_path], check=True, capture_output=True)
        print(f"✅ 桌面快捷方式创建成功: {desktop_shortcut}")
    except Exception as e:
        print(f"⚠️ 桌面快捷方式创建失败: {e}")
    
    # 2. 创建开始菜单快捷方式
    print("🔗 创建开始菜单快捷方式...")
    start_menu_dir = os.path.join(os.path.expanduser("~"), "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs")
    os.makedirs(start_menu_dir, exist_ok=True)
    start_menu_shortcut = os.path.join(start_menu_dir, "GitHub Desktop.lnk")
    
    startmenu_vbs = f"""
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{start_menu_shortcut}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{github_exe}"
oLink.WorkingDirectory = "{os.path.dirname(github_exe)}"
oLink.Description = "GitHub Desktop 中文版"
oLink.Save
"""
    
    startmenu_vbs_path = os.path.join(target_dir, "create_startmenu_shortcut.vbs")
    with open(startmenu_vbs_path, "w", encoding="gbk") as f:
        f.write(startmenu_vbs)
    
    try:
        subprocess.run(['cscript', '//nologo', startmenu_vbs_path], check=True, capture_output=True)
        print(f"✅ 开始菜单快捷方式创建成功")
    except Exception as e:
        print(f"⚠️ 开始菜单快捷方式创建失败: {e}")
    
    # 3. 创建目标目录快捷方式
    print("🔗 在目标目录创建快捷方式...")
    target_shortcut = os.path.join(target_dir, "GitHub Desktop.lnk")
    
    target_vbs = f"""
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{target_shortcut}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{github_exe}"
oLink.WorkingDirectory = "{os.path.dirname(github_exe)}"
oLink.Description = "GitHub Desktop 中文版 - AI网站开发专用"
oLink.Save
"""
    
    target_vbs_path = os.path.join(target_dir, "create_target_shortcut.vbs")
    with open(target_vbs_path, "w", encoding="gbk") as f:
        f.write(target_vbs)
    
    try:
        subprocess.run(['cscript', '//nologo', target_vbs_path], check=True, capture_output=True)
        print(f"✅ 目标目录快捷方式创建成功: {target_shortcut}")
    except Exception as e:
        print(f"⚠️ 目标目录快捷方式创建失败: {e}")
    
    # 4. 创建启动脚本
    print("📝 创建启动脚本...")
    launch_script = f"""@echo off
echo 启动 GitHub Desktop 中文版...
echo 安装位置: {os.path.dirname(github_exe)}
echo 快捷方式位置: {target_dir}
echo.
echo 如果界面不是中文，请按以下步骤设置:
echo 1. 打开 GitHub Desktop
echo 2. 点击菜单 File → Options
echo 3. 选择 Appearance 标签
echo 4. 在 Language 下拉框选择 "简体中文"
echo 5. 重启 GitHub Desktop
echo.
echo 按任意键启动 GitHub Desktop...
pause >nul
start "" "{github_exe}"
"""
    
    launch_script_path = os.path.join(target_dir, "启动GitHub.bat")
    with open(launch_script_path, "w", encoding="gbk") as f:
        f.write(launch_script)
    
    print(f"✅ 启动脚本创建成功: {launch_script_path}")
    
    # 5. 创建AI网站项目专用配置指南
    print("📚 创建AI网站项目配置指南...")
    ai_project_guide = f"""# 🚀 GitHub Desktop 配置指南 - AI网站项目专用
## 📍 快捷方式位置
- 桌面快捷方式: `{desktop_shortcut}`
- 开始菜单: GitHub Desktop
- 本目录快捷方式: `GitHub Desktop.lnk`
- 启动脚本: `启动GitHub.bat`
## 🎯 为AI网站项目配置
### 1. 登录GitHub账号
1. 打开GitHub Desktop
2. 点击 "Sign in to GitHub.com"
3. 输入您的GitHub账号密码
### 2. 配置Git用户信息（重要！）
打开命令行，执行:
```bash
git config --global user.name "您的名字"
git config --global user.email "您的邮箱@example.com"
git config --global core.autocrlf true
```
### 3. 克隆AI网站项目
1. 在GitHub Desktop中点击 "Clone a repository"
2. 选择 "URL" 标签
3. 输入: `https://github.com/您的用户名/ai-website-platform.git`
4. 本地路径选择: `D:\\AI项目\\ai-website-platform`
5. 点击 "Clone"
### 4. 日常开发工作流
```mermaid
graph LR
    A[拉取最新代码] --> B[修改代码]
    B --> C[提交更改]
    C --> D[推送到GitHub]
    D --> E[Vercel自动部署]
    E --> F[网站自动更新]
```
### 5. 设置中文界面（如需要）
1. File → Options
2. Appearance 标签
3. Language 选择 "简体中文"
4. 重启GitHub Desktop
## 🔧 常用操作
| 操作 | 快捷键 | 说明 |
|------|--------|------|
| 提交更改 | Ctrl+Enter | 提交当前更改 |
| 推送代码 | Ctrl+P | 推送到GitHub |
| 拉取代码 | Ctrl+Shift+P | 从GitHub拉取最新 |
| 新建仓库 | Ctrl+Shift+N | 创建新仓库 |
| 打开仓库 | Ctrl+Shift+O | 打开现有仓库 |
## 📁 项目目录结构
```
D:\\AI项目\\ai-website-platform\\
├── src/                    # 源代码
├── docs/                   # 文档
├── public/                 # 静态资源
├── .env.local             # 环境变量（不要提交！）
└── package.json           # 项目配置
```
## ⚠️ 注意事项
1. **绝对不要**提交 `.env.local` 文件到GitHub
2. 每次推送前先拉取最新代码
3. 提交信息要清晰描述更改内容
4. 使用分支开发，合并到main分支
## 🚀 快速开始
1. 双击 `启动GitHub.bat`
2. 登录GitHub账号
3. 克隆AI网站项目
4. 开始开发！
---
*配置时间: {subprocess.check_output(["date", "/t"], text=True).strip()}*
*由AiPy小章鱼团队为您优化配置*
"""
    
    guide_path = os.path.join(target_dir, "AI网站项目配置指南.md")
    with open(guide_path, "w", encoding="utf-8") as f:
        f.write(ai_project_guide)
    
    print(f"✅ 配置指南创建成功: {guide_path}")
    
    # 6. 创建配置文件
    config = {
        "github_desktop": {
            "executable_path": github_exe,
            "install_dir": os.path.dirname(github_exe),
            "shortcuts": {
                "desktop": desktop_shortcut,
                "start_menu": start_menu_shortcut,
                "target_dir": target_shortcut
            },
            "scripts": {
                "launch_script": launch_script_path,
                "config_guide": guide_path
            }
        },
        "ai_project": {
            "recommended_path": r"D:\AI项目\ai-website-platform",
            "git_config": {
                "user_name": "需要设置",
                "user_email": "需要设置",
                "autocrlf": "true"
            },
            "repository_url": "https://github.com/您的用户名/ai-website-platform.git"
        },
        "setup_time": subprocess.check_output(["date", "/t"], text=True).strip()
    }
    
    config_path = os.path.join(target_dir, "github_config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 配置文件创建成功: {config_path}")
    
    # 7. 尝试启动GitHub Desktop验证
    print("\n🚀 尝试启动GitHub Desktop验证配置...")
    try:
        subprocess.Popen([github_exe], shell=True)
        print("✅ GitHub Desktop 启动成功！")
        print("   请检查界面是否为中文，如不是请按指南设置")
    except Exception as e:
        print(f"⚠️ 启动失败: {e}")
        print(f"   请手动双击: {target_shortcut}")
    
    # 总结
    print("\n" + "="*60)
    print("🎉 GitHub Desktop 配置完成！")
    print("="*60)
    print(f"📁 配置目录: {target_dir}")
    print(f"🚀 启动方式:")
    print(f"   1. 双击桌面快捷方式")
    print(f"   2. 开始菜单 → GitHub Desktop")
    print(f"   3. 运行: {launch_script_path}")
    print(f"📚 配置指南: {guide_path}")
    print(f"⚙️ 配置文件: {config_path}")
    print("\n🎯 下一步:")
    print("1. 打开GitHub Desktop登录账号")
    print("2. 配置Git用户信息（重要！）")
    print("3. 克隆AI网站项目")
    print("4. 开始开发！")
    print("="*60)
    
    return {
        "status": "configured",
        "target_directory": target_dir,
        "github_executable": github_exe,
        "shortcuts_created": {
            "desktop": desktop_shortcut,
            "start_menu": start_menu_shortcut,
            "target_dir": target_shortcut
        },
        "files_created": [
            "启动GitHub.bat",
            "AI网站项目配置指南.md",
            "github_config.json",
            "GitHub Desktop.lnk"
        ],
        "next_steps": [
            "登录GitHub账号",
            "配置Git用户信息",
            "克隆AI网站项目",
            "设置中文界面（如需要）"
        ]
    }
if __name__ == "__main__":
    result = setup_github_desktop()
    utils.set_state(success=True, result=result)