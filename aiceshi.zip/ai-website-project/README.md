# AI多功能网站平台
## 项目概述
基于Next.js + Supabase + AI APIs + 微信支付宝支付 + Vercel的一站式AI创作平台。
## 技术栈
- **前端**: Next.js 14+ (App Router), React, TypeScript, Tailwind CSS
- **后端**: Next.js API Routes, Supabase (PostgreSQL, Auth, Storage)
- **AI服务**: OpenAI API, Stable Diffusion, RunwayML/Sora API
- **支付**: 微信支付, 支付宝
- **部署**: Vercel (Serverless, CDN, Edge Functions)
- **监控**: Vercel Analytics, Sentry, Logtail
## 功能特性
1. 🤖 AI聊天对话 (GPT-4)
2. 🎨 图像生成 (DALL-E 3, Stable Diffusion)
3. 🎬 视频生成 (Sora API, RunwayML)
4. 💳 支付系统 (微信/支付宝)
5. 👤 用户系统 (注册/登录/订阅)
6. 📊 管理后台 (用户/内容/财务)
## 快速开始
```bash
# 克隆项目
git clone <repository-url>
# 安装依赖
npm install
# 环境配置
cp .env.example .env.local
# 启动开发服务器
npm run dev
```
## 开发指南
详细开发文档请查看 `docs/` 目录。
## 部署
项目已配置Vercel一键部署，支持自动CI/CD。
## 许可证
MIT License
