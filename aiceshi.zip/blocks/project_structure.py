import os
import json
import shutil
from pathlib import Path
def create_project_structure():
    """创建完整的项目文档结构"""
    
    print("📁 开始创建AI网站项目文档结构...")
    
    # 项目根目录结构
    project_structure = {
        "ai-website-platform": {
            "docs": {
                "architecture": ["system-architecture.md", "database-design.md", "api-design.md"],
                "requirements": ["business-requirements.md", "functional-spec.md", "non-functional-spec.md"],
                "design": ["ui-design.md", "ux-flow.md", "component-design.md"],
                "api": ["openapi-spec.yaml", "api-reference.md", "webhook-spec.md"],
                "deployment": ["deployment-guide.md", "env-config.md", "monitoring-setup.md"]
            },
            "src": {
                "app": {
                    "api": {
                        "auth": ["route.ts", "types.ts"],
                        "chat": ["route.ts", "types.ts"],
                        "image": ["route.ts", "types.ts"],
                        "video": ["route.ts", "types.ts"],
                        "payment": ["route.ts", "types.ts"],
                        "webhook": ["route.ts", "types.ts"]
                    },
                    "(auth)": {
                        "login": ["page.tsx", "layout.tsx"],
                        "register": ["page.tsx", "layout.tsx"],
                        "callback": ["page.tsx", "layout.tsx"]
                    },
                    "(dashboard)": {
                        "chat": ["page.tsx", "layout.tsx", "components"],
                        "image": ["page.tsx", "layout.tsx", "components"],
                        "video": ["page.tsx", "layout.tsx", "components"],
                        "billing": ["page.tsx", "layout.tsx", "components"],
                        "profile": ["page.tsx", "layout.tsx", "components"]
                    },
                    "(admin)": {
                        "users": ["page.tsx", "layout.tsx"],
                        "content": ["page.tsx", "layout.tsx"],
                        "analytics": ["page.tsx", "layout.tsx"],
                        "settings": ["page.tsx", "layout.tsx"]
                    },
                    "globals.css": None,
                    "layout.tsx": None,
                    "page.tsx": None
                },
                "components": {
                    "ui": ["button.tsx", "input.tsx", "card.tsx", "modal.tsx", "table.tsx"],
                    "layout": ["header.tsx", "sidebar.tsx", "footer.tsx", "navbar.tsx"],
                    "chat": ["message.tsx", "input.tsx", "history.tsx", "typing.tsx"],
                    "image": ["generator.tsx", "gallery.tsx", "editor.tsx", "preview.tsx"],
                    "video": ["player.tsx", "editor.tsx", "timeline.tsx", "controls.tsx"],
                    "payment": ["checkout.tsx", "pricing.tsx", "invoice.tsx", "history.tsx"]
                },
                "lib": {
                    "supabase": ["client.ts", "auth.ts", "database.ts", "storage.ts"],
                    "openai": ["client.ts", "chat.ts", "image.ts", "video.ts"],
                    "payment": ["wechat.ts", "alipay.ts", "webhook.ts", "order.ts"],
                    "utils": ["format.ts", "validation.ts", "encryption.ts", "cache.ts"],
                    "types": ["index.ts", "user.ts", "chat.ts", "payment.ts"]
                },
                "styles": {
                    "globals.css": None,
                    "components.css": None,
                    "themes": ["light.css", "dark.css", "variables.css"]
                },
                "hooks": {
                    "useAuth.ts": None,
                    "useChat.ts": None,
                    "usePayment.ts": None,
                    "useMedia.ts": None,
                    "useToast.ts": None
                },
                "store": {
                    "auth.store.ts": None,
                    "chat.store.ts": None,
                    "payment.store.ts": None,
                    "ui.store.ts": None
                }
            },
            "public": {
                "images": ["logo.svg", "favicon.ico", "og-image.png"],
                "fonts": ["inter.woff2", "inter.woff"],
                "icons": ["chat.svg", "image.svg", "video.svg", "payment.svg"]
            },
            "tests": {
                "unit": ["auth.test.ts", "chat.test.ts", "payment.test.ts"],
                "integration": ["api.test.ts", "webhook.test.ts", "e2e.test.ts"],
                "fixtures": ["user.json", "chat.json", "payment.json"]
            },
            "scripts": {
                "deploy.sh": None,
                "build.sh": None,
                "test.sh": None,
                "seed.js": None
            },
            "config": {
                "next.config.js": None,
                "tailwind.config.js": None,
                "tsconfig.json": None,
                "package.json": None,
                ".env.example": None,
                ".gitignore": None
            }
        }
    }
    
    # 创建目录结构
    def create_dirs(base_path, structure):
        for name, content in structure.items():
            path = os.path.join(base_path, name)
            
            if content is None:  # 文件
                Path(path).parent.mkdir(parents=True, exist_ok=True)
                Path(path).touch()
                print(f"   📄 创建文件: {path}")
            elif isinstance(content, dict):  # 目录
                os.makedirs(path, exist_ok=True)
                print(f"   📂 创建目录: {path}/")
                create_dirs(path, content)
            elif isinstance(content, list):  # 目录包含文件
                os.makedirs(path, exist_ok=True)
                print(f"   📂 创建目录: {path}/")
                for file in content:
                    file_path = os.path.join(path, file)
                    Path(file_path).touch()
                    print(f"     📄 创建文件: {file_path}")
    
    # 创建项目结构
    project_root = "ai-website-project"
    if os.path.exists(project_root):
        shutil.rmtree(project_root)
    
    create_dirs(project_root, project_structure)
    
    # 创建关键文档内容
    create_key_documents(project_root)
    
    print(f"\n✅ 项目文档结构创建完成！")
    print(f"📁 项目根目录: {project_root}")
    print(f"📊 总目录数: {count_dirs(project_root)}")
    print(f"📄 总文件数: {count_files(project_root)}")
    
    return project_root
def create_key_documents(project_root):
    """创建关键文档内容"""
    
    # 1. README.md
    readme_content = """# AI多功能网站平台
## 项目概述
基于Next.js + Supabase + AI APIs + 微信支付宝支付 + Vercel的一站式AI创作平台。
## 技术栈
- **前端**: Next.js 14+ (App Router), React, TypeScript, Tailwind CSS
- **后端**: Next.js API Routes, Supabase (PostgreSQL, Auth, Storage)
- **AI服务**: OpenAI API, Stable Diffusion, RunwayML/Sora API
- **支付**: 微信支付, 支付宝
- **部署**: Vercel (Serverless, CDN, Edge Functions)
- **监控**: Vercel Analytics, Sentry, Logtail
## 功能特性
1. 🤖 AI聊天对话 (GPT-4)
2. 🎨 图像生成 (DALL-E 3, Stable Diffusion)
3. 🎬 视频生成 (Sora API, RunwayML)
4. 💳 支付系统 (微信/支付宝)
5. 👤 用户系统 (注册/登录/订阅)
6. 📊 管理后台 (用户/内容/财务)
## 快速开始
```bash
# 克隆项目
git clone <repository-url>
# 安装依赖
npm install
# 环境配置
cp .env.example .env.local
# 启动开发服务器
npm run dev
```
## 开发指南
详细开发文档请查看 `docs/` 目录。
## 部署
项目已配置Vercel一键部署，支持自动CI/CD。
## 许可证
MIT License
"""
    
    with open(os.path.join(project_root, "README.md"), "w", encoding="utf-8") as f:
        f.write(readme_content)
    
    # 2. 架构文档
    arch_content = """# 系统架构设计
## 架构概览
```
用户层 (Next.js前端) → 应用层 (API Routes) → 服务层 (AI/支付) → 数据层 (Supabase)
```
## 技术选型说明
### 前端架构
- **Next.js 14+**: 支持SSR/SSG/ISR，App Router提供更好的路由体验
- **TypeScript**: 类型安全，提高代码质量
- **Tailwind CSS**: 原子化CSS，快速UI开发
### 后端架构
- **Supabase**: 完整的BaaS解决方案，包含数据库、认证、存储
- **Next.js API Routes**: 前后端一体化，减少上下文切换
- **Serverless Functions**: 按需扩展，成本优化
### AI集成
- **OpenAI API**: GPT-4聊天，DALL-E 3图像生成
- **Stable Diffusion**: 开源图像生成，成本可控
- **RunwayML/Sora**: 视频生成能力
### 支付集成
- **微信支付**: 国内主流支付方式
- **支付宝**: 覆盖广泛用户群体
- **聚合支付**: 统一支付接口，简化集成
## 数据流设计
1. 用户请求 → Next.js前端
2. 前端调用API Routes
3. API调用Supabase/AI服务
4. 返回结果给用户
"""
    
    arch_path = os.path.join(project_root, "docs", "architecture", "system-architecture.md")
    with open(arch_path, "w", encoding="utf-8") as f:
        f.write(arch_content)
    
    # 3. 环境配置示例
    env_content = """# 环境变量配置
# 复制此文件为 .env.local 并填写实际值
# Supabase配置
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
# OpenAI配置
OPENAI_API_KEY=sk-your-openai-api-key
OPENAI_ORGANIZATION=org-your-org-id
# 图像生成配置
STABLE_DIFFUSION_API_KEY=your-stable-diffusion-key
STABLE_DIFFUSION_API_URL=https://api.stability.ai
# 视频生成配置
RUNWAYML_API_KEY=your-runwayml-key
SORA_API_KEY=your-sora-key
# 支付配置
WECHAT_APP_ID=your-wechat-app-id
WECHAT_MCH_ID=your-wechat-merchant-id
WECHAT_API_KEY=your-wechat-api-key
ALIPAY_APP_ID=your-alipay-app-id
ALIPAY_PRIVATE_KEY=your-alipay-private-key
ALIPAY_PUBLIC_KEY=your-alipay-public-key
# 其他配置
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=http://localhost:3000
# 部署配置
VERCEL_PROJECT_ID=your-vercel-project-id
VERCEL_TEAM_ID=your-vercel-team-id
"""
    
    env_path = os.path.join(project_root, ".env.example")
    with open(env_path, "w", encoding="utf-8") as f:
        f.write(env_content)
    
    print("   📝 关键文档已创建: README.md, 架构文档, 环境配置")
def count_dirs(path):
    """统计目录数量"""
    count = 0
    for root, dirs, files in os.walk(path):
        count += len(dirs)
    return count
def count_files(path):
    """统计文件数量"""
    count = 0
    for root, dirs, files in os.walk(path):
        count += len(files)
    return count
if __name__ == "__main__":
    project_path = create_project_structure()
    
    # 生成结构报告
    structure_report = {
        "project_name": "AI多功能网站平台",
        "project_path": project_path,
        "total_directories": count_dirs(project_path),
        "total_files": count_files(project_path),
        "main_directories": [
            "docs/ - 项目文档",
            "src/ - 源代码",
            "public/ - 静态资源",
            "tests/ - 测试文件",
            "config/ - 配置文件"
        ],
        "created_at": "2026-04-08"
    }
    
    with open("project_structure_report.json", "w", encoding="utf-8") as f:
        json.dump(structure_report, f, ensure_ascii=False, indent=2)
    
    utils.set_state(success=True, 
                   project_path=project_path,
                   report="project_structure_report.json")