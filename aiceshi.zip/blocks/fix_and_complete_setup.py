import os
import subprocess
import json
import datetime
def fix_and_complete_setup():
    """修复并完成GitHub Desktop配置"""
    
    print("🔧 石破天继续完成配置...")
    
    # 目标目录
    target_dir = r"D:\软件\AI智能体\GitHub电脑版"
    
    # 确保目录存在
    os.makedirs(target_dir, exist_ok=True)
    
    # GitHub Desktop可执行文件路径
    github_exe = r"C:\Users\840G6\AppData\Local\GitHubDesktop\GitHubDesktop.exe"
    
    if not os.path.exists(github_exe):
        print("❌ GitHub Desktop可执行文件不存在")
        return {"status": "not_found"}
    
    print(f"✅ 使用GitHub Desktop: {github_exe}")
    
    # 继续创建AI网站项目配置指南（修复日期获取问题）
    print("📚 继续创建AI网站项目配置指南...")
    
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    ai_project_guide = f"""# 🚀 GitHub Desktop 配置指南 - AI网站项目专用
## 📍 快捷方式位置
- 桌面快捷方式: `C:\\Users\\840G6\\Desktop\\GitHub Desktop.lnk`
- 开始菜单: GitHub Desktop
- 本目录快捷方式: `GitHub Desktop.lnk`
- 启动脚本: `启动GitHub.bat`
## 🎯 为AI网站项目配置
### 1. 登录GitHub账号
1. 打开GitHub Desktop
2. 点击 "Sign in to GitHub.com"
3. 输入您的GitHub账号密码
### 2. 配置Git用户信息（重要！）
打开命令行，执行:
```bash
git config --global user.name "您的名字"
git config --global user.email "您的邮箱@example.com"
git config --global core.autocrlf true
```
### 3. 克隆AI网站项目
1. 在GitHub Desktop中点击 "Clone a repository"
2. 选择 "URL" 标签
3. 输入: `https://github.com/您的用户名/ai-website-platform.git`
4. 本地路径选择: `D:\\AI项目\\ai-website-platform`
5. 点击 "Clone"
### 4. 日常开发工作流
```
拉取最新代码 → 修改代码 → 提交更改 → 推送到GitHub → Vercel自动部署 → 网站自动更新
```
### 5. 设置中文界面（如需要）
1. File → Options
2. Appearance 标签
3. Language 选择 "简体中文"
4. 重启GitHub Desktop
## 🔧 常用操作
| 操作 | 快捷键 | 说明 |
|------|--------|------|
| 提交更改 | Ctrl+Enter | 提交当前更改 |
| 推送代码 | Ctrl+P | 推送到GitHub |
| 拉取代码 | Ctrl+Shift+P | 从GitHub拉取最新 |
| 新建仓库 | Ctrl+Shift+N | 创建新仓库 |
| 打开仓库 | Ctrl+Shift+O | 打开现有仓库 |
## 📁 项目目录结构
```
D:\\AI项目\\ai-website-platform\\
├── src/                    # 源代码
├── docs/                   # 文档
├── public/                 # 静态资源
├── .env.local             # 环境变量（不要提交！）
└── package.json           # 项目配置
```
## ⚠️ 注意事项
1. **绝对不要**提交 `.env.local` 文件到GitHub
2. 每次推送前先拉取最新代码
3. 提交信息要清晰描述更改内容
4. 使用分支开发，合并到main分支
## 🚀 快速开始
1. 双击 `启动GitHub.bat`
2. 登录GitHub账号
3. 克隆AI网站项目
4. 开始开发！
---
*配置时间: {current_time}*
*由AiPy小章鱼团队为您优化配置*
"""
    
    guide_path = os.path.join(target_dir, "AI网站项目配置指南.md")
    with open(guide_path, "w", encoding="utf-8") as f:
        f.write(ai_project_guide)
    
    print(f"✅ 配置指南创建成功: {guide_path}")
    
    # 创建配置文件
    config = {
        "github_desktop": {
            "executable_path": github_exe,
            "install_dir": os.path.dirname(github_exe),
            "shortcuts": {
                "desktop": r"C:\Users\840G6\Desktop\GitHub Desktop.lnk",
                "start_menu": r"C:\Users\840G6\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\GitHub Desktop.lnk",
                "target_dir": os.path.join(target_dir, "GitHub Desktop.lnk")
            },
            "scripts": {
                "launch_script": os.path.join(target_dir, "启动GitHub.bat"),
                "config_guide": guide_path
            }
        },
        "ai_project": {
            "recommended_path": r"D:\AI项目\ai-website-platform",
            "git_config": {
                "user_name": "需要设置",
                "user_email": "需要设置",
                "autocrlf": "true"
            },
            "repository_url": "https://github.com/您的用户名/ai-website-platform.git"
        },
        "setup_time": current_time
    }
    
    config_path = os.path.join(target_dir, "github_config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 配置文件创建成功: {config_path}")
    
    # 创建一键配置脚本
    print("⚙️ 创建一键配置脚本...")
    
    setup_script = f"""@echo off
echo ========================================
echo    GitHub Desktop 一键配置脚本
echo ========================================
echo.
echo 正在配置 GitHub Desktop 用于 AI 网站开发...
echo.
echo 1. 检查 Git 配置
echo 2. 创建项目目录
echo 3. 配置开发环境
echo.
echo 按任意键开始配置...
pause >nul
echo.
echo [1/3] 检查 Git 配置...
where git >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Git 已安装
) else (
    echo ❌ Git 未安装，请先安装 Git
    echo 下载地址: https://git-scm.com/download/win
    pause
    exit /b 1
)
echo.
echo [2/3] 创建项目目录...
if not exist "D:\\AI项目" (
    mkdir "D:\\AI项目"
    echo ✅ 创建目录: D:\\AI项目
) else (
    echo ✅ 目录已存在: D:\\AI项目
)
echo.
echo [3/3] 配置 Git 用户信息...
echo 请设置您的 Git 用户名和邮箱:
echo.
set /p git_name="请输入您的名字: "
set /p git_email="请输入您的邮箱: "
git config --global user.name "%git_name%"
git config --global user.email "%git_email%"
git config --global core.autocrlf true
echo.
echo ✅ Git 配置完成！
echo   用户名: %git_name%
echo   邮箱: %git_email%
echo.
echo ========================================
echo   配置完成！
echo ========================================
echo.
echo 🎯 下一步操作:
echo 1. 打开 GitHub Desktop (双击桌面快捷方式)
echo 2. 登录您的 GitHub 账号
echo 3. 克隆 AI 网站项目
echo 4. 开始开发！
echo.
echo 详细指南请查看: {guide_path}
echo.
pause
"""
    
    setup_script_path = os.path.join(target_dir, "一键配置.bat")
    with open(setup_script_path, "w", encoding="gbk") as f:
        f.write(setup_script)
    
    print(f"✅ 一键配置脚本创建成功: {setup_script_path}")
    
    # 创建快速启动菜单
    print("📋 创建快速启动菜单...")
    
    quick_menu = f"""@echo off
:menu
cls
echo ========================================
echo    GitHub Desktop 快速启动菜单
echo ========================================
echo.
echo 请选择操作:
echo.
echo [1] 启动 GitHub Desktop
echo [2] 一键配置开发环境
echo [3] 查看配置指南
echo [4] 打开配置目录
echo [5] 检查 Git 配置
echo [6] 启动命令行
echo [7] 退出
echo.
set /p choice="请选择 (1-7): "
echo.
if "%choice%"=="1" goto start_github
if "%choice%"=="2" goto setup_env
if "%choice%"=="3" goto view_guide
if "%choice%"=="4" goto open_dir
if "%choice%"=="5" goto check_git
if "%choice%"=="6" goto start_cmd
if "%choice%"=="7" goto exit
echo 无效选择，请重新输入
pause
goto menu
:start_github
echo 正在启动 GitHub Desktop...
start "" "{github_exe}"
echo ✅ GitHub Desktop 已启动
pause
goto menu
:setup_env
echo 运行一键配置脚本...
call "{setup_script_path}"
goto menu
:view_guide
echo 打开配置指南...
start "" "{guide_path}"
echo ✅ 配置指南已打开
pause
goto menu
:open_dir
echo 打开配置目录...
explorer "{target_dir}"
echo ✅ 目录已打开
pause
goto menu
:check_git
echo 检查 Git 配置...
echo.
echo Git 版本:
git --version
echo.
echo Git 用户配置:
git config --global user.name
git config --global user.email
echo.
echo Git 自动换行设置:
git config --global core.autocrlf
echo.
pause
goto menu
:start_cmd
echo 启动命令行...
start cmd /k "cd /d {target_dir} && echo AI网站开发环境已就绪"
goto menu
:exit
echo 再见！
exit /b 0
"""
    
    menu_path = os.path.join(target_dir, "快速启动菜单.bat")
    with open(menu_path, "w", encoding="gbk") as f:
        f.write(quick_menu)
    
    print(f"✅ 快速启动菜单创建成功: {menu_path}")
    
    # 尝试启动GitHub Desktop验证
    print("\n🚀 尝试启动GitHub Desktop验证配置...")
    try:
        subprocess.Popen([github_exe], shell=True)
        print("✅ GitHub Desktop 启动成功！")
        print("   请检查界面是否为中文，如不是请按指南设置")
    except Exception as e:
        print(f"⚠️ 启动失败: {e}")
        print(f"   请手动双击: {os.path.join(target_dir, 'GitHub Desktop.lnk')}")
    
    # 总结
    print("\n" + "="*60)
    print("🎉 GitHub Desktop 配置完成！")
    print("="*60)
    print(f"📁 配置目录: {target_dir}")
    print(f"🚀 启动方式:")
    print(f"   1. 双击桌面快捷方式")
    print(f"   2. 开始菜单 → GitHub Desktop")
    print(f"   3. 运行: {os.path.join(target_dir, '启动GitHub.bat')}")
    print(f"   4. 运行: {menu_path} (推荐)")
    print(f"📚 配置指南: {guide_path}")
    print(f"⚙️ 配置文件: {config_path}")
    print(f"🔧 配置脚本: {setup_script_path}")
    print("\n🎯 下一步操作:")
    print("1. 运行 '一键配置.bat' 配置Git用户信息")
    print("2. 打开GitHub Desktop登录账号")
    print("3. 克隆AI网站项目")
    print("4. 开始开发！")
    print("="*60)
    
    # 列出目录内容
    print("\n📂 目录内容:")
    for item in os.listdir(target_dir):
        item_path = os.path.join(target_dir, item)
        if os.path.isfile(item_path):
            size = os.path.getsize(item_path)
            print(f"   📄 {item} ({size:,} bytes)")
        else:
            print(f"   📁 {item}")
    
    return {
        "status": "configured",
        "target_directory": target_dir,
        "github_executable": github_exe,
        "files_created": [
            "AI网站项目配置指南.md",
            "github_config.json",
            "一键配置.bat",
            "快速启动菜单.bat",
            "启动GitHub.bat",
            "GitHub Desktop.lnk"
        ],
        "shortcuts": {
            "desktop": r"C:\Users\840G6\Desktop\GitHub Desktop.lnk",
            "start_menu": r"C:\Users\840G6\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\GitHub Desktop.lnk",
            "target_dir": os.path.join(target_dir, "GitHub Desktop.lnk")
        },
        "next_steps": [
            "运行 '一键配置.bat' 配置Git用户信息",
            "打开GitHub Desktop登录账号",
            "克隆AI网站项目",
            "设置中文界面（如需要）"
        ]
    }
if __name__ == "__main__":
    result = fix_and_complete_setup()
    utils.set_state(success=True, result=result)