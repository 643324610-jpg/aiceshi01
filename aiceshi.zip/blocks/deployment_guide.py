import json
from datetime import datetime
def create_deployment_guide():
    """创建详细的部署启动指南"""
    
    deployment_guide = {
        "前置准备": {
            "注册账号": [
                {
                    "平台": "GitHub",
                    "作用": "代码托管",
                    "注册地址": "https://github.com/",
                    "说明": "免费注册，用于存放代码"
                },
                {
                    "平台": "Supabase",
                    "作用": "数据库和用户认证",
                    "注册地址": "https://supabase.com/",
                    "说明": "免费层级可用，足够起步"
                },
                {
                    "平台": "Vercel",
                    "作用": "一键部署网站",
                    "注册地址": "https://vercel.com/",
                    "说明": "可以直接用GitHub账号登录，免费层级可用"
                },
                {
                    "平台": "OpenAI",
                    "作用": "AI聊天和图像生成API",
                    "注册地址": "https://platform.openai.com/",
                    "说明": "需要充值API密钥，按使用量付费"
                },
                {
                    "平台": "Stability AI",
                    "作用": "Stable Diffusion图像生成API",
                    "注册地址": "https://platform.stability.ai/",
                    "说明": "可选，用于额外图像生成"
                },
                {
                    "平台": "RunwayML",
                    "作用": "视频生成API",
                    "注册地址": "https://runwayml.com/",
                    "说明": "需要申请访问权限"
                },
                {
                    "平台": "微信支付商户平台",
                    "作用": "微信支付接入",
                    "注册地址": "https://pay.weixin.qq.com/",
                    "说明": "需要营业执照，商户认证"
                },
                {
                    "平台": "支付宝开放平台",
                    "作用": "支付宝接入",
                    "注册地址": "https://open.alipay.com/",
                    "说明": "需要营业执照，商户认证"
                }
            ],
            "准备工具": [
                "Git (用于代码版本控制)",
                "Node.js 18+ (本地开发环境)",
                "编辑器 (VS Code推荐)",
                "命令行终端"
            ]
        },
        "第一步：本地开发环境搭建": [
            {
                "步骤": "克隆或创建项目",
                "命令": [
                    "git clone <你的项目地址>",
                    "cd 项目目录",
                    "npm install"
                ],
                "说明": "安装所有依赖包"
            },
            {
                "步骤": "配置环境变量",
                "命令": [
                    "cp .env.example .env.local"
                ],
                "说明": "打开 .env.local 文件，填入所有API密钥：",
                "需要填写": [
                    "NEXT_PUBLIC_SUPABASE_URL (从Supabase获取)",
                    "NEXT_PUBLIC_SUPABASE_ANON_KEY (从Supabase获取)",
                    "SUPABASE_SERVICE_ROLE_KEY (从Supabase获取)",
                    "OPENAI_API_KEY (从OpenAI获取)",
                    "WECHAT_APP_ID (微信支付获取)",
                    "WECHAT_MCH_ID (微信支付商户号)",
                    "WECHAT_API_KEY (微信支付API密钥)",
                    "ALIPAY_APP_ID (支付宝获取)",
                    "ALIPAY_PRIVATE_KEY (支付宝私钥)",
                    "ALIPAY_PUBLIC_KEY (支付宝公钥)",
                    "NEXTAUTH_SECRET (自己生成一个随机字符串)",
                    "NEXTAUTH_URL=http://localhost:3000"
                ]
            },
            {
                "步骤": "启动本地开发服务器",
                "命令": [
                    "npm run dev"
                ],
                "说明": "启动后访问 http://localhost:3000 即可看到网站"
            },
            {
                "步骤": "本地测试",
                "检查项": [
                    "注册登录功能正常",
                    "AI聊天正常响应",
                    "图像生成功能正常",
                    "支付流程测试通过"
                ]
            }
        ],
        "第二步：Supabase配置": {
            "创建项目": [
                "登录Supabase官网",
                "点击 \"New project\"",
                "选择Organization，输入项目名",
                "选择区域（选离你近的）",
                "点击 \"Create new project\"",
                "等待项目创建完成（大约1-2分钟）"
            ],
            "获取API信息": [
                "进入项目 → Settings → API",
                "复制 \"Project URL\" → 填写到 NEXT_PUBLIC_SUPABASE_URL",
                "复制 \"anon public\" → 填写到 NEXT_PUBLIC_SUPABASE_ANON_KEY",
                "复制 \"service_role\" → 填写到 SUPABASE_SERVICE_ROLE_KEY"
            ],
            "创建数据库表": [
                "打开SQL Editor → New query",
                "执行建表SQL，创建用户表、对话记录表、订单表等",
                "启用Row Level Security (RLS) 保证数据安全"
            ],
            "配置认证": [
                "Authentication → Settings",
                "配置邮件确认、注册限制等",
                "启用社交登录（可选）",
                "配置回调地址"
            ],
            "配置存储": [
                "Storage → Create bucket",
                "创建用于存储用户上传图片和生成文件的bucket",
                "配置存储访问权限"
            ]
        },
        "第三步：推送到GitHub": {
            "步骤": [
                "在GitHub上创建新仓库",
                "本地初始化Git：git init",
                "添加远程地址：git remote add origin <仓库地址>",
                "添加所有文件：git add .",
                "提交：git commit -m \"Initial commit\"",
                "推送：git push -u origin main"
            ],
            "注意事项": [
                "确保 .env.local 已经在 .gitignore 中",
                "不要提交API密钥到代码仓库"
            ]
        },
        "第四步：Vercel一键部署": {
            "方法一：通过Vercel网站导入（推荐新手）": [
                "登录Vercel官网",
                "点击 \"New Project\"",
                "选择你刚才创建的GitHub仓库",
                "Vercel会自动识别这是Next.js项目",
                "在 \"Environment Variables\" 填入所有环境变量（和本地 .env.local 一样）",
                "点击 \"Deploy\"",
                "等待部署完成（大约2-5分钟）",
                "完成！Vercel会给你一个域名，直接访问就能打开网站"
            ],
            "方法二：通过Vercel CLI命令行部署": [
                "安装Vercel CLI：npm i -g vercel",
                "登录：vercel login",
                "部署：vercel --prod",
                "按照提示一步步操作即可"
            ],
            "Vercel自动完成": [
                "✅ 自动安装依赖",
                "✅ 自动构建项目",
                "✅ 自动配置SSL证书（HTTPS）",
                "✅ 自动部署到全球CDN",
                "✅ 自动分配域名",
                "✅ 之后每次推送到GitHub，自动重新部署"
            ],
            "部署后的操作": [
                "在Vercel项目设置中更新 NEXTAUTH_URL 为你的Vercel域名",
                "在Supabase认证设置中添加Vercel域名到允许的回调地址",
                "测试网站所有功能是否正常"
            ]
        },
        "第五步：支付配置": {
            "微信支付配置": [
                "登录微信支付商户平台",
                "申请API证书",
                "下载证书文件",
                "配置API密钥",
                "设置异步通知地址（Webhook）为 https://你的域名/api/webhook/wechat",
                "保存商户号和API信息"
            ],
            "支付宝配置": [
                "登录支付宝开放平台",
                "创建应用",
                "申请支付权限",
                "生成并下载应用私钥和支付宝公钥",
                "设置异步通知地址为 https://你的域名/api/webhook/alipay",
                "保存应用ID和密钥信息"
            ],
            "域名备案": [
                "注意：中国境内提供支付服务需要ICP备案",
                "如果你的域名在国内服务器需要备案，使用Vercel境外节点可跳过",
                "建议使用国内域名解析服务商，根据服务商指引完成备案"
            ]
        },
        "第六步：配置域名（可选）": {
            "如果你有自己的域名": [
                "在Vercel项目 → Settings → Domains",
                "输入你的域名，按照提示配置DNS",
                "等待DNS解析生效（通常几分钟到几小时）",
                "Vercel自动配置SSL证书，HTTPS生效"
            ]
        },
        "如何打开访问网站": {
            "本地开发": "浏览器打开 http://localhost:3000",
            "线上预览": "Vercel会给你一个类似 xxx.vercel.app 的域名",
            "自定义域名": "直接访问你配置的域名，比如 https://ai.yourdomain.com",
            "注意": "第一次打开可能需要几秒钟，Vercel Serverless会冷启动"
        },
        "日常更新部署": {
            "修改代码后": [
                "git add .",
                "git commit -m \"Update: xxx\"",
                "git push origin main",
                "Vercel自动检测到推送，自动重新部署，几分钟后更新完成"
            ],
            "环境变量修改": [
                "在Vercel项目 → Settings → Environment Variables 修改",
                "然后重新部署一次即可生效"
            ]
        },
        "常见问题排查": {
            "网站打不开": [
                "检查Vercel部署是否成功，查看部署日志",
                "检查环境变量是否都填写正确",
                "检查构建是否出错，查看错误信息"
            ],
            "Supabase连接失败": [
                "检查URL和API密钥是否正确",
                "检查项目是否在Supabase中正常运行",
                "检查网络是否能访问Supabase"
            ],
            "AI API调用失败": [
                "检查API密钥是否正确",
                "检查账户余额是否充足",
                "检查API调用配额是否用完",
                "检查网络是否能访问OpenAI等API"
            ],
            "支付回调失败": [
                "检查通知地址是否正确可访问",
                "检查签名验证配置是否正确",
                "查看服务器日志排查具体错误"
            ],
            "部署慢": [
                "这是正常的，Vercel免费层构建资源有限，大约3-5分钟完成",
                "付费版会快很多"
            ]
        },
        "监控和运维": {
            "Vercel监控": "Vercel Dashboard查看部署状态和性能",
            "Sentry错误监控": "集成Sentry，自动捕获错误并通知",
            "API用量监控": "在OpenAI、Supabase等平台查看使用量和费用",
            "日志查看": "Vercel查看函数执行日志，方便排查问题"
        },
        "总结快速部署步骤": """
1. 注册所有需要的平台账号 (GitHub, Supabase, Vercel, OpenAI, 微信支付宝)
2. 本地配置好项目代码和环境变量，测试运行
3. 推送到GitHub仓库
4. Vercel导入GitHub项目，填入环境变量，点击Deploy
5. 等待2-5分钟，部署完成，直接访问域名即可打开！
"""
    }
    
    # 生成HTML格式的部署指南
    generate_deployment_html(deployment_guide)
    
    # 保存JSON格式
    with open("deployment_guide.json", "w", encoding="utf-8") as f:
        json.dump(deployment_guide, f, ensure_ascii=False, indent=2)
    
    print("✅ 部署指南生成完成！")
    print("📄 JSON文件: deployment_guide.json")
    print("🌐 HTML页面: deployment_guide.html")
    
    return deployment_guide
def generate_deployment_html(data):
    """生成HTML格式的部署指南"""
    
    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI网站平台完整部署指南 - 一步一步教你部署上线</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', 'Microsoft YaHei', -apple-system, BlinkMacSystemFont, sans-serif;
            line-height: 1.7;
            color: #2c3e50;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.2rem;
            margin-bottom: 10px;
            font-weight: 700;
        }}
        
        .header .subtitle {{
            font-size: 1.2rem;
            opacity: 0.9;
        }}
        
        .content {{
            padding: 40px;
        }}
        
        .section {{
            margin-bottom: 40px;
            padding: 30px;
            background: #f8f9fa;
            border-radius: 15px;
            border-left: 5px solid #667eea;
            transition: all 0.3s ease;
        }}
        
        .section:hover {{
            transform: translateX(5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }}
        
        .section h2 {{
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.8rem;
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 10px;
        }}
        
        .section h3 {{
            color: #764ba2;
            margin: 20px 0 15px;
            font-size: 1.4rem;
        }}
        
        .section h4 {{
            color: #2c3e50;
            margin: 15px 0 10px;
            font-size: 1.1rem;
        }}
        
        .step-list {{
            list-style: none;
            padding-left: 0;
        }}
        
        .step-list li {{
            padding: 12px 0 12px 40px;
            position: relative;
            border-bottom: 1px solid #eee;
        }}
        
        .step-list li:before {{
            content: "➜";
            color: #667eea;
            position: absolute;
            left: 10px;
            font-weight: bold;
        }}
        
        .platform-card {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        
        .platform-item {{
            background: white;
            padding: 15px;
            border-radius: 10px;
            border: 1px solid #e9ecef;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        }}
        
        .platform-name {{
            font-weight: bold;
            color: #667eea;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }}
        
        .platform-role {{
            color: #764ba2;
            font-size: 0.9rem;
            margin-bottom: 5px;
        }}
        
        .platform-link {{
            font-size: 0.85rem;
            word-break: break-all;
        }}
        
        .platform-link a {{
            color: #3498db;
            text-decoration: none;
        }}
        
        .platform-link a:hover {{
            text-decoration: underline;
        }}
        
        .command-block {{
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            overflow-x: auto;
            font-family: 'Consolas', 'Monaco', monospace;
        }}
        
        .check-list {{
            list-style: none;
            padding-left: 0;
        }}
        
        .check-list li {{
            padding: 8px 0 8px 30px;
            position: relative;
        }}
        
        .check-list li:before {{
            content: "✓";
            color: #27ae60;
            position: absolute;
            left: 0;
            font-weight: bold;
        }}
        
        .problem-item {{
            background: #fff5f5;
            border-left: 4px solid #e74c3c;
            padding: 15px;
            margin: 10px 0;
            border-radius: 0 8px 8px 0;
        }}
        
        .problem-title {{
            font-weight: bold;
            color: #c0392b;
            margin-bottom: 5px;
        }}
        
        .quick-start {{
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
        }}
        
        .quick-start h2 {{
            color: white;
            border-bottom: 2px solid rgba(255,255,255,0.3);
        }}
        
        .quick-start ol {{
            text-align: left;
            padding-left: 20px;
            font-size: 1.1rem;
            line-height: 2;
        }}
        
        .footer {{
            text-align: center;
            padding: 30px;
            color: #6c757d;
            border-top: 1px solid #e9ecef;
        }}
        
        .badge {{
            display: inline-block;
            padding: 4px 12px;
            background: #667eea;
            color: white;
            border-radius: 20px;
            font-size: 0.8rem;
            margin: 2px;
        }}
        
        .badge-free {{
            background: #27ae60;
        }}
        
        .badge-paid {{
            background: #f39c12;
        }}
        
        @media (max-width: 768px) {{
            .container {{
                border-radius: 10px;
            }}
            .header {{
                padding: 20px;
            }}
            .header h1 {{
                font-size: 1.6rem;
            }}
            .content {{
                padding: 20px;
            }}
            .section {{
                padding: 20px;
            }}
            .platform-card {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 AI网站平台完整部署指南</h1>
            <div class="subtitle">一步一步教你将Next.js + Supabase + AI项目一键部署到Vercel</div>
        </div>
        
        <div class="content">
            <div class="quick-start">
                <h2>🎯 快速部署总览</h2>
                <ol>
                    <li>注册所有需要的平台账号</li>
                    <li>本地配置项目和环境变量</li>
                    <li>推送到GitHub仓库</li>
                    <li>Vercel导入项目，一键部署</li>
                    <li>等待2-5分钟，直接访问域名打开！</li>
                </ol>
            </div>
            
            <div class="section">
                <h2>📋 前置准备 - 需要注册的平台</h2>
                <p>在开始部署之前，你需要在这些平台注册账号，大部分都有免费层级可以起步：</p>
                
                <div class="platform-card">
                    {''.join([f'''
                    <div class="platform-item">
                        <div class="platform-name">{item['平台']} <span class="badge {'badge-free' if '免费' in item['说明'] else 'badge-paid'}">{ '免费' if '免费' in item['说明'] else '付费'}</span></div>
                        <div class="platform-role">{item['作用']}</div>
                        <div class="platform-link"><a href="{item['注册地址']}" target="_blank">{item['注册地址']}</a></div>
                        <div style="font-size: 0.8rem; color: #7f8c8d; margin-top: 5px;">{item['说明']}</div>
                    </div>
                    ''' for item in data['前置准备']['注册账号']])}
                </div>
                
                <h3>需要准备的工具</h3>
                <ul class="check-list">
                    {''.join([f'<li>{tool}</li>' for tool in data['前置准备']['准备工具']])}
                </ul>
            </div>
            
            <div class="section">
                <h2>1️⃣ 第一步：本地开发环境搭建</h2>
                <ol class="step-list">
                    {''.join([f'''
                    <li>
                        <strong>{item['步骤']}</strong>
                        {item.get('命令', '') and f'<div class="command-block"><code>{"<br>".join(item["命令"])}</code></div>' or ''}
                        <p style="margin-top: 8px; color: #7f8c8d;">{item['说明']}</p>
                        {item.get('需要填写', '') and f'''
                        <h4>需要填写：</h4>
                        <ul class="check-list">
                            {''.join([f'<li>{key}</li>' for key in item['需要填写']])}
                        </ul>
                        ''' or ''}
                        {item.get('检查项', '') and f'''
                        <h4>检查项：</h4>
                        <ul class="check-list">
                            {''.join([f'<li>{check}</li>' for check in item['检查项']])}
                        </ul>
                        ''' or ''}
                    </li>
                    ''' for item in data['第一步：本地开发环境搭建']])}
                </ol>
            </div>
            
            <div class="section">
                <h2>2️⃣ 第二步：Supabase配置</h2>
                
                <h3>创建新项目</h3>
                <ul class="check-list">
                    {''.join([f'<li>{step}</li>' for step in data['第二步：Supabase配置']['创建项目']])}
                </ul>
                
                <h3>获取API信息</h3>
                <ul class="check-list">
                    {''.join([f'<li>{step}</li>' for step in data['第二步：Supabase配置']['获取API信息']])}
                </ul>
                
                <h3>数据库配置</h3>
                <ul class="check-list">
                    {''.join([f'<li>{step}</li>' for step in data['第二步：Supabase配置']['创建数据库表']])}
                </ul>
                
                <h3>认证配置</h3>
                <ul class="check-list">
                    {''.join([f'<li>{step}</li>' for step in data['第二步：Supabase配置']['配置认证']])}
                </ul>
                
                <h3>存储配置</h3>
                <ul class="check-list">
                    {''.join([f'<li>{step}</li>' for step in data['第二步：Supabase配置']['配置存储']])}
                </ul>
            </div>
            
            <div class="section">
                <h2>3️⃣ 第三步：推送到GitHub</h2>
                <div class="command-block">
                    <code>
# 在GitHub上创建新仓库后，执行以下命令<br>
git init<br>
git remote add origin &lt;你的GitHub仓库地址&gt;<br>
git add .<br>
git commit -m "Initial commit"<br>
git push -u origin main
                    </code>
                </div>
                <h4>⚠️ 重要注意事项：</h4>
                <ul class="check-list">
                    <li>确保 <code>.env.local</code> 已经在 <code>.gitignore</code> 中</li>
                    <li><strong>绝对不要</strong>把API密钥提交到代码仓库</li>
                </ul>
            </div>
            
            <div class="section">
                <h2>4️⃣ 第四步：Vercel一键部署</h2>
                
                <h3>方法一：通过Vercel网站导入（推荐新手）</h3>
                <ol class="step-list">
                    {''.join([f'<li>{step}</li>' for step in data['第四步：Vercel一键部署']['方法一：通过Vercel网站导入（推荐新手）']])}
                </ol>
                
                <h3>Vercel自动帮你完成这些：</h3>
                <ul class="check-list">
                    {''.join([f'<li>{item}</li>' for item in data['第四步：Vercel一键部署']['Vercel自动完成']])}
                </ul>
                
                <h3>部署后需要做：</h3>
                <ul class="check-list">
                    {''.join([f'<li>{item}</li>' for item in data['第四步：Vercel一键部署']['部署后的操作']])}
                </ul>
            </div>
            
            <div class="section">
                <h2>5️⃣ 第五步：支付配置</h2>
                
                <h3>微信支付配置</h3>
                <ol class="step-list">
                    {''.join([f'<li>{step}</li>' for step in data['第五步：支付配置']['微信支付配置']])}
                </ol>
                
                <h3>支付宝配置</h3>
                <ol class="step-list">
                    {''.join([f'<li>{step}</li>' for step in data['第五步：支付配置']['支付宝配置']])}
                </ol>
                
                <h3>⚠️ 重要提醒 - 域名备案</h3>
                <ul class="check-list">
                    {''.join([f'<li>{item}</li>' for item in data['第五步：支付配置']['域名备案']])}
                </ul>
            </div>
            
            <div class="section">
                <h2>🌐 如何打开访问网站</h2>
                <ul class="check-list">
                    <li><strong>本地开发：</strong> 浏览器直接打开 <code>http://localhost:3000</code></li>
                    <li><strong>线上预览：</strong> Vercel会自动给你一个域名，类似 <code>xxx.vercel.app</code>，直接访问即可</li>
                    <li><strong>自定义域名：</strong> 配置自己的域名后，直接访问，比如 <code>https://ai.yourdomain.com</code></li>
                    <li><strong>注意：</strong> 第一次打开可能需要几秒，这是Vercel Serverless冷启动，正常现象</li>
                </ul>
            </div>
            
            <div class="section">
                <h2>🔄 日常更新部署</h2>
                <p>修改代码后只需要这几步，Vercel自动更新：</p>
                <div class="command-block">
                    <code>
git add .<br>
git commit -m "Update: 功能说明"<br>
git push origin main<br>
# 推送完成后，Vercel自动检测到变化，自动重新部署！
                    </code>
                </div>
                <p>几分钟后，你的更新就上线了，就是这么简单！🎉</p>
            </div>
            
            <div class="section">
                <h2>🔧 常见问题排查</h2>
                {''.join([f'''
                <div class="problem-item">
                    <div class="problem-title">{problem}</div>
                    <ul class="check-list">
                        {''.join([f'<li>{item}</li>' for item in solutions])}
                    </ul>
                </div>
                ''' for problem, solutions in data['常见问题排查'].items()])}
            </div>
            
            <div class="section">
                <h2>📊 监控和运维</h2>
                <ul class="check-list">
                    {''.join([f'<li>{item}</li>' for item in [
                        "Vercel Dashboard查看部署状态和性能",
                        "Sentry错误监控：自动捕获错误并通知",
                        "API用量监控：在各平台查看使用量和费用",
                        "日志查看：Vercel查看函数执行日志，方便排查问题"
                    ]])}
                </ul>
            </div>
            
            <div class="quick-start">
                <h2>✅ 总结：快速6步走</h2>
                <div style="text-align: left; font-size: 1.2rem; line-height: 2.2;">
                    <ol>
                        <li>注册所有平台账号 <span class="badge badge-free">大部分免费</span></li>
                        <li>本地配置项目，测试运行正常</li>
                        <li>推送到GitHub仓库</li>
                        <li>Vercel导入项目，填入环境变量</li>
                        <li>点击Deploy，等待2-5分钟</li>
                        <li><strong>完成！直接访问Vercel给你的域名就能打开网站！ 🎉</strong></li>
                    </ol>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>Generated by <a href="https://www.aipyaipy.com" target="_blank">AiPy</a> | 本地数据处理，不上传任何信息</p>
            <p style="margin-top: 10px; font-size: 0.9rem;">AI网站平台部署指南 © 2026 | Vercel真正做到一键上线，太方便了！</p>
        </div>
    </div>
</body>
</html>"""
    
    with open("deployment_guide.html", "w", encoding="utf-8") as f:
        f.write(html_content)
    
    print("   🌐 HTML部署指南: deployment_guide.html")
if __name__ == "__main__":
    guide = create_deployment_guide()
    utils.set_state(success=True, 
                   guide_files=["deployment_guide.json", "deployment_guide.html"],
                   message="完整部署指南生成完成")