import matplotlib.pyplot as plt
from matplotlib import font_manager
import matplotlib.patches as patches
import numpy as np
import os
def create_architecture_diagram():
    """创建系统架构图"""
    
    # 下载中文字体
    import requests
    font_url = "https://dl.aipyaipy.com/bp/SourceHanSansCN-Regular.otf"
    font_path = "SourceHanSansCN-Regular.otf"
    
    if not os.path.exists(font_path):
        print("📥 下载中文字体...")
        response = requests.get(font_url)
        with open(font_path, "wb") as f:
            f.write(response.content)
        print("✅ 字体下载完成")
    
    # 设置中文字体
    font_manager.fontManager.addfont(font_path)
    prop = font_manager.FontProperties(fname=font_path)
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.family'] = prop.get_name()
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # 设置背景色
    fig.patch.set_facecolor('#f8f9fa')
    ax.set_facecolor('#f8f9fa')
    
    # 标题
    ax.text(8, 9.5, 'AI网站平台系统架构图', 
            fontsize=24, fontweight='bold', 
            ha='center', color='#2c3e50')
    ax.text(8, 8.8, 'Next.js + Supabase + AI APIs + 微信支付宝支付 + Vercel部署', 
            fontsize=14, ha='center', color='#7f8c8d')
    
    # 定义颜色
    colors = {
        'frontend': '#3498db',    # 蓝色
        'backend': '#2ecc71',     # 绿色
        'ai': '#9b59b6',          # 紫色
        'payment': '#e74c3c',     # 红色
        'deploy': '#f39c12',      # 橙色
        'database': '#1abc9c',    # 青色
        'storage': '#34495e'      # 深灰
    }
    
    # 1. 用户层
    ax.add_patch(patches.Rectangle((1, 6.5), 3, 1.5, 
                                   facecolor=colors['frontend'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(2.5, 7.25, '用户界面层', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(2.5, 6.9, 'Next.js 14+', fontsize=11, ha='center', color='white')
    ax.text(2.5, 6.6, 'React + TypeScript', fontsize=10, ha='center', color='white')
    
    # 2. 应用层
    ax.add_patch(patches.Rectangle((5, 6.5), 6, 1.5, 
                                   facecolor=colors['backend'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(8, 7.25, '应用服务层', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(8, 6.9, 'Next.js API Routes', fontsize=11, ha='center', color='white')
    ax.text(8, 6.6, 'Server Components', fontsize=10, ha='center', color='white')
    
    # 3. AI服务层
    ax.add_patch(patches.Rectangle((12, 6.5), 3, 1.5, 
                                   facecolor=colors['ai'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(13.5, 7.25, 'AI服务层', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(13.5, 6.9, 'OpenAI API', fontsize=11, ha='center', color='white')
    ax.text(13.5, 6.6, 'Stable Diffusion', fontsize=10, ha='center', color='white')
    
    # 4. 数据层
    ax.add_patch(patches.Rectangle((5, 4), 6, 1.5, 
                                   facecolor=colors['database'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(8, 4.75, '数据存储层', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(8, 4.4, 'Supabase PostgreSQL', fontsize=11, ha='center', color='white')
    ax.text(8, 4.05, '实时订阅 + 存储', fontsize=10, ha='center', color='white')
    
    # 5. 支付层
    ax.add_patch(patches.Rectangle((1, 2.5), 3, 1.5, 
                                   facecolor=colors['payment'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(2.5, 3.25, '支付网关', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(2.5, 2.9, '微信支付', fontsize=11, ha='center', color='white')
    ax.text(2.5, 2.55, '支付宝', fontsize=11, ha='center', color='white')
    
    # 6. 部署层
    ax.add_patch(patches.Rectangle((12, 2.5), 3, 1.5, 
                                   facecolor=colors['deploy'], 
                                   edgecolor='white', 
                                   linewidth=2, 
                                   alpha=0.9))
    ax.text(13.5, 3.25, '部署平台', fontsize=14, fontweight='bold', 
            ha='center', color='white')
    ax.text(13.5, 2.9, 'Vercel', fontsize=11, ha='center', color='white')
    ax.text(13.5, 2.55, '一键部署 + CDN', fontsize=10, ha='center', color='white')
    
    # 连接线
    # 用户层 -> 应用层
    ax.annotate('', xy=(4.2, 7), xytext=(5, 7),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(4.6, 7.2, 'HTTP请求', fontsize=9, ha='center', color='#7f8c8d')
    
    # 应用层 -> AI服务层
    ax.annotate('', xy=(11, 7), xytext=(12, 7),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(11.5, 7.2, 'API调用', fontsize=9, ha='center', color='#7f8c8d')
    
    # 应用层 -> 数据层
    ax.annotate('', xy=(8, 6), xytext=(8, 5.5),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(8.3, 5.75, '数据操作', fontsize=9, ha='center', color='#7f8c8d')
    
    # 应用层 -> 支付层
    ax.annotate('', xy=(5, 5.5), xytext=(4, 4),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(4.5, 4.8, '支付请求', fontsize=9, ha='center', color='#7f8c8d')
    
    # 支付层 -> 应用层
    ax.annotate('', xy=(4, 3), xytext=(5, 4.5),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(4.5, 3.7, '回调通知', fontsize=9, ha='center', color='#7f8c8d')
    
    # 应用层 -> 部署层
    ax.annotate('', xy=(11, 5.5), xytext=(12, 4),
                arrowprops=dict(arrowstyle='->', lw=2, color='#7f8c8d'))
    ax.text(11.5, 4.8, '部署', fontsize=9, ha='center', color='#7f8c8d')
    
    # 功能模块标注
    modules = [
        ("聊天对话", 2.5, 5.5),
        ("图像生成", 5.5, 5.5),
        ("视频生成", 8.5, 5.5),
        ("用户管理", 11.5, 5.5),
        ("支付管理", 2.5, 1.5),
        ("订单管理", 5.5, 1.5),
        ("内容审核", 8.5, 1.5),
        ("数据统计", 11.5, 1.5)
    ]
    
    for text, x, y in modules:
        ax.text(x, y, text, fontsize=10, ha='center', 
                bbox=dict(boxstyle="round,pad=0.3", 
                         facecolor='white', 
                         edgecolor='#bdc3c7', 
                         alpha=0.8))
    
    # 技术优势标注
    advantages = [
        ("前后端一体化", 2.5, 0.8),
        ("实时数据库", 5.5, 0.8),
        ("AI能力集成", 8.5, 0.8),
        ("一键部署", 11.5, 0.8)
    ]
    
    for text, x, y in advantages:
        ax.text(x, y, text, fontsize=9, ha='center', 
                style='italic', color='#7f8c8d')
    
    # 保存图片
    plt.tight_layout()
    plt.savefig('architecture_diagram.png', dpi=300, bbox_inches='tight', 
                facecolor=fig.get_facecolor())
    plt.savefig('architecture_diagram.svg', format='svg', 
                bbox_inches='tight', facecolor=fig.get_facecolor())
    
    print("✅ 系统架构图已生成！")
    print("📁 保存文件：")
    print("   - architecture_diagram.png (PNG格式)")
    print("   - architecture_diagram.svg (SVG矢量格式)")
    
    # 显示图片
    plt.show()
    
    return True
if __name__ == "__main__":
    success = create_architecture_diagram()
    utils.set_state(success=success, 
                   files=["architecture_diagram.png", "architecture_diagram.svg"])